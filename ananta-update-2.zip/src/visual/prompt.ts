// ─────────────────────────────────────────────────────────────────
// Prompts that turn a curriculum concept into board pictures, written
// to match how the tutor teaches (docs/TUTOR_PERSONA.md):
//
//   §4 session arc — teach ONE idea, then check; build before testing
//   §7 representations — the board shows only what is being said;
//      one step per board bullet; choose from the authored ideas
//   §8 errors — a misconception gets a CONTRAST CASE, not a correction
//   §10 language — the error belongs to the rule, never the learner
//   §15 integrity — an application picture never gives the answer
//
// The model is given the concept's own authored material (key facts,
// the worked examples verified at ingest, misconceptions with their
// probes, the evidence ladder and representation ideas) and a small
// drawing vocabulary. It decides what to draw; src/visual/sanitize.ts
// then fact-checks what it drew.
// ─────────────────────────────────────────────────────────────────
import type { CurriculumConcept, CurriculumSubject } from '../adaptive/learnerModel';
import { REPRESENTATION_DESCRIPTIONS, DEFAULT_REPRESENTATION_ORDER } from '../persona/representations';
import { gradeLevelFromLabel } from '../curriculum/catalog';
import { VISUAL_LIMITS } from './types';

export type SubjectModeId = 'well_structured' | 'interpretive' | 'skill';

export interface MisconceptionInput {
  id?: string;
  belief: string;
  triggerPattern?: string;
  probeQuestion?: string;
  correctionHint?: string;
}

export interface VisualConceptContext {
  topic: string;
  grade: string;
  subjectLabel?: string;
  subjectMode?: SubjectModeId;
  chapter?: string;
  keyFacts: string[];
  /** Worked examples checked by the ingest review (docs/CURRICULUM.md §4). */
  workedExamples: string[];
  misconceptions: MisconceptionInput[];
  ladderItems: Array<{ level: number; prompt: string; lookFor: string; id?: string; hints?: string[] }>;
  representationIdeas: Array<{ strategy: string; idea: string }>;
  prerequisites?: string[];
  /** Ingest-time decision about a photo / a 3D model for this concept (undefined = not decided → none). */
  presentation?: import('../adaptive/learnerModel').ConceptPresentation;
}

/** `drawn` = shapes, graphs, parts. `worked` = a step-by-step working laid out on the board (equations, tables, annotations). */
export type BoardForm = 'drawn' | 'worked';

export type VisualRequest =
  /** `keyFacts` = the 1-based key facts this picture is responsible for (one idea per picture, docs/BOARD_VISUALS.md §Planner). */
  | { purpose: 'teach'; focus?: string; keyFacts?: number[]; form?: BoardForm; representation?: { strategy: string; idea: string } }
  | { purpose: 'contrast'; misconception: MisconceptionInput; form?: BoardForm }
  | { purpose: 'apply'; item: { level: number; prompt: string; lookFor: string }; form?: BoardForm }
  | { purpose: 'space' };

/** Build the prompt context from a curriculum concept (server / pregen). */
export function conceptContext(
  concept: CurriculumConcept,
  course?: Pick<CurriculumSubject, 'label' | 'grade' | 'subjectMode'> | null,
  gradeOverride?: string,
): VisualConceptContext {
  const misconceptions: MisconceptionInput[] = concept.misconceptionDetails?.length
    ? concept.misconceptionDetails.map((m) => ({
        id: m.id, belief: m.belief, triggerPattern: m.triggerPattern,
        probeQuestion: m.probeQuestion, correctionHint: m.correctionHint,
      }))
    : (concept.commonMisconceptions || []).map((belief) => ({ belief }));
  return {
    topic: concept.label,
    grade: gradeOverride || course?.grade || 'Grade 8',
    subjectLabel: course?.label,
    subjectMode: (course?.subjectMode as SubjectModeId | undefined) ?? 'well_structured',
    chapter: concept.chapter,
    keyFacts: concept.keyFacts || [],
    workedExamples: concept.workedExamples || [],
    misconceptions,
    ladderItems: (concept.ladderItems || []).map((l) => ({ level: l.level, prompt: l.prompt, lookFor: l.lookFor, id: l.id, hints: l.hints })),
    representationIdeas: (concept.representationIdeas || []).map((r) => ({ strategy: r.strategy, idea: r.idea })),
    prerequisites: (concept.prerequisiteDetails || []).map((p) => p.label),
    presentation: concept.presentation,
  };
}

/** Minimal context for an ad-hoc topic that is not in any course. */
export function adHocContext(topic: string, grade: string): VisualConceptContext {
  return { topic, grade, keyFacts: [], workedExamples: [], misconceptions: [], ladderItems: [], representationIdeas: [] };
}

function ageFor(grade: string): string {
  const level = gradeLevelFromLabel(grade);
  return level !== undefined ? `${level + 5}-year-old` : 'secondary-school';
}

const list = (items: string[], empty: string) => (items.length ? items.map((s, i) => `  ${i + 1}. ${s}`).join('\n') : `  ${empty}`);

// ─── the drawing vocabulary (shared by every 2D prompt) ──────────

const VOCABULARY_2D = `THE DRAWING VOCABULARY — compose the picture from these bricks. There are no templates:
choose whatever combination shows THIS idea best.

FRAME (pick one)
  "plane"  real maths coordinates, y points UP, drawn with real axes and numbers:
           {"kind":"plane","x":[xmin,xmax],"y":[ymin,ymax],"axes":"both","grid":true,"equalScale":true,"xLabel":"x","yLabel":"y"}
           graphs, coordinates, geometry, vectors. Number line or timeline: "axes":"x" (y is ignored, put things at y = 0).
           equalScale true = 1 unit on x is as long as 1 unit on y (needed for true shapes and angles).
  "canvas" free layout space, x 0..100 left→right, y 0..60 top→bottom: {"kind":"canvas"}
           processes, cycles, cause and effect, labelled parts of an object, algebra working line by line, comparisons.

BRICKS — every brick has a unique short "id"; optional "name" (how you would SAY it aloud, e.g. "the vertical line"),
"label" (text drawn beside it, max 4 words or one formula) and "color" (ink | muted | emerald | amber | sky | violet | rose | teal).
  point     {"kind":"point","at":[x,y],"style":"solid"}                  "open" = hollow (e.g. a point NOT included)
  segment   {"kind":"segment","from":[x,y],"to":[x,y],"arrow":"none","dashed":false}   arrow: none|end|start|both
  line      {"kind":"line","through":[[x1,y1],[x2,y2]]}                  infinite straight line — plane only
  ray       {"kind":"ray","from":[x,y],"through":[x,y]}                  starts at "from", runs off the board — plane only
  polygon   {"kind":"polygon","points":[[x,y],[x,y],[x,y]],"fill":true}  shapes, shaded regions
  polyline  {"kind":"polyline","points":[[x,y],...],"arrow":"end"}       paths, zig-zags, curved-ish routes
  circle    {"kind":"circle","center":[x,y],"r":2,"fill":false}          add "ry" for an ellipse
  angle     {"kind":"angle","vertex":[x,y],"from":[x,y],"to":[x,y],"right":true}   angle mark; "right":true draws the square — plane only
  function  {"kind":"function","expr":"2x + 1","domain":[-3,3]}          the curve y = expr (x, + - * / ^, sqrt, sin, cos, tan, abs, log, ln, exp, pi) — plane only
  text      {"kind":"text","at":[x,y],"text":"3x + 6 = 12","size":"md","math":true}   size: sm|md|lg|xl
  box       {"kind":"box","at":[x,y],"text":"Evaporation","sub":"water → vapour"}      centred on "at" — canvas only
  connector {"kind":"connector","from":"<brick id>","to":"<brick id>","label":"heat","arrow":"end","bend":0.3}   joins two bricks by their edges
  table     {"kind":"table","rows":[["x","y"],["0","1"],["1","3"]],"placement":"right"}   at most one; drawn beside the picture`;

const VOCABULARY_3D = `THE 3D VOCABULARY — frame {"kind":"space","x":[min,max],"y":[min,max],"z":[min,max],"axes":true}.
x points right, y points UP, z points toward the viewer. Every brick has "id", optional "name", "label", "color"
(ink | muted | emerald | amber | sky | violet | rose | teal).
  point     {"kind":"point","at":[x,y,z]}
  segment   {"kind":"segment","from":[x,y,z],"to":[x,y,z],"arrow":"end","dashed":false}
  polygon   {"kind":"polygon","points":[[x,y,z],...],"fill":true}         a flat face, plane region or cross-section
  sphere    {"kind":"sphere","center":[x,y,z],"r":1,"wireframe":false}
  cuboid    {"kind":"cuboid","center":[x,y,z],"size":[w,h,d],"wireframe":false}
  cylinder  {"kind":"cylinder","from":[x,y,z],"to":[x,y,z],"r":1,"rTop":1}  rTop 0 = cone
  label     {"kind":"label","at":[x,y,z],"text":"height = 5 cm"}`;

const STEPS_SPEC = `STEPS — the picture is a teaching sequence, revealed by the tutor as it speaks.
"steps":[{"id":"s1","name":"<2-5 words the tutor will say to reveal it; unique>","caption":"<one sentence the learner reads, max 18 words>",
          "show":["ids that appear at this step"],"focus":["ids to spotlight now"],"phase":"hook|teach|contrast|check|apply"}]
  • 3 to ${VISUAL_LIMITS.maxSteps - 1} steps. ONE idea per step. Each step adds only what its caption talks about —
    the board shows only what is being said, never everything at once.
  • EVERY brick with a label, text or box must be listed in exactly one step's "show". A brick in no step is on the
    board from the start, which spoils the build-up. Every step must add something ("show" not empty) or spotlight something ("focus").
  • Step 1 anchors the learner (the axes, the object, the situation); the idea is then built up piece by piece.`;

const PERSONA_RULES = `HOW THIS TUTOR TEACHES — the picture must follow these (an automatic checker enforces them):
  • PREDICT FIRST. The caption of step 1 is a QUESTION that makes the learner predict or notice something
    ("Where do you think the line y = 3 sits?"). It never contains the answer. Later captions may state what is now visible.
  • ASK AT THE END. "checkQuestion" is one question, ending in "?", pointing at the finished picture. The last step's caption asks it.
  • SHOW, don't assert. Draw the thing itself: the shapes, points, lines, arrows and parts. At most a third of the bricks may be text;
    a picture that is mostly written sentences is a slide, not a picture.
  • Draw exactly what you label. If a label says "3 body parts" draw 3 parts; "8 legs" needs eight; "largest" must be the largest;
    a count, order or direction in a caption must be true of the drawing. Do not label anything you have not drawn.
  • Nothing the learner needs may be missing: if a structure is shared by all examples (every plant cell has a nucleus), draw it.
  • Never pre-announce a mix-up. A picture never says "common mistake" or "misconception".`;

const TRUTH_RULES = `TRUTH AND CLARITY RULES (an automatic checker enforces these; a false label is deleted before a child sees it)
  • Every label must be exactly true for what is drawn: a label "(2, -2)" only on a point AT [2,-2];
    "x = 2" only on a line whose points all have x = 2; "y = 2x + 1" only on that exact line or curve;
    a right-angle mark only where the angle really is 90°; lengths like "5 cm" only where the drawn length is 5 on the axes.
  • When you draw an example, reuse the NUMBERS from the verified worked examples below if they fit — they were checked.
  • Coordinates you mention in captions must be on the board.
  • Keep text short: labels are words or formulas, captions are one sentence. No paragraphs on the board.
  • Leave room: no two labelled things closer than ~1 unit on a plane or ~10 units on the canvas, so labels never collide.
    Choose plane ranges with a margin around everything important.
  • Canvas layout: keep every brick between x 8..92 and y 8..52 (never on the very edge). Boxes are about 24 units wide and 13 tall:
    put them at least 28 units apart left-to-right and 16 apart top-to-bottom, and never let a connector run through another brick.
  • Put an equation label ON the line or curve it names (a "text" equation must sit within 1 unit of that line), or label the line itself.
  • Colour carries meaning: one colour per idea, the same colour for everything belonging to it; ink = neutral, muted = scaffolding.
  • At most ${VISUAL_LIMITS.maxElements - 8} bricks. Prefer fewer, clearer bricks.`;

function languageRules(age: string) {
  return `LANGUAGE (the tutor's own rules): captions and labels are for a ${age}. Warm, plain words.
  Never "wrong", "incorrect", "mistake", "mistaken", "impossible" or "silly"; never a tick, cross or emoji. A mix-up is "a rule worth testing" —
  the error belongs to the rule, never the learner. Never compare learners.`;
}

export function conceptBlock(ctx: VisualConceptContext) {
  const order = DEFAULT_REPRESENTATION_ORDER[ctx.subjectMode ?? 'well_structured'];
  const repDescriptions = order.map((r) => `  ${r}: ${REPRESENTATION_DESCRIPTIONS[r]}`).join('\n');
  return `CONCEPT: "${ctx.topic}"${ctx.chapter ? ` (${ctx.chapter})` : ''}
LEARNER: ${ctx.grade}${ctx.subjectLabel ? `, ${ctx.subjectLabel}` : ''}

KEY FACTS the learner must come to understand:
${list(ctx.keyFacts, '(none given — use the standard facts for this concept at this grade)')}

VERIFIED WORKED EXAMPLES (numbers checked at ingest — reuse them):
${list(ctx.workedExamples, '(none — choose simple whole numbers and double-check them)')}

KNOWN MISCONCEPTIONS for this concept:
${list(ctx.misconceptions.map((m) => `${m.id ? `[${m.id}] ` : ''}${m.belief}${m.correctionHint ? ` — correction: ${m.correctionHint}` : ''}`), '(none recorded)')}

REPRESENTATION IDEAS the curriculum authored for this concept (realise one of these when it fits):
${list(ctx.representationIdeas.map((r) => `${r.strategy}: ${r.idea}`), '(none — choose the clearest representation yourself)')}

The tutor's representation catalogue, in this subject's default order:
${repDescriptions}

ACCURACY: state only what is true for ${ctx.grade} in this subject. If you are unsure of a fact, draw less rather than guess.`;
}

const OUTPUT_2D = `Return ONLY this JSON (no markdown):
{"dim":"2d","title":"<short title>","purpose":"<teach|contrast|apply>","representation":"<one representation id from the catalogue>",
 "why":"<one sentence: what this picture lets the learner SEE that words alone would not>",
 "frame":{...},"elements":[...],"steps":[...],"checkQuestion":"<one question, ending in ?, the tutor asks pointing at the finished picture>"}`;

/** Which key facts a teaching picture is responsible for, as prompt text. */
function keyFactScope(ctx: VisualConceptContext, nums: number[] | undefined): string {
  if (!nums?.length || !ctx.keyFacts.length) return '';
  const mine = nums.filter((n) => n >= 1 && n <= ctx.keyFacts.length);
  if (!mine.length) return '';
  return `\n  • This picture is responsible ONLY for key fact${mine.length > 1 ? 's' : ''} ${mine.join(' and ')}: ${mine.map((n) => `"${ctx.keyFacts[n - 1]}"`).join(' and ')}.
    Draw that one idea completely and leave the other key facts to their own pictures.`;
}

/** The main generation prompt for one picture. */
export function buildVisualPrompt(ctx: VisualConceptContext, req: VisualRequest): string {
  const age = ageFor(ctx.grade);
  const header = `You design the picture a patient, expert tutor builds on the board while teaching a ${age}.
The tutor teaches ONE idea at a time, asks before it tells, shows before it explains, then checks understanding. Your picture must do real
teaching work — make the idea VISIBLE so the learner can see why it is true — not decorate the lesson.`;

  if (req.purpose === 'space') {
    return `${header}

${conceptBlock(ctx)}

TASK: decide whether a 3D model would genuinely help the learner understand THIS concept. Say "useful": true ONLY when BOTH hold:
  (a) the idea is intrinsically spatial — solids, surfaces, volume, 3D coordinates, rotation, orbits, molecular or layered structure — and
  (b) a rotatable model shows something a flat picture cannot.
Processes, cycles, classification, comparisons, graphs, equations, algebra and anything whose labels would just float in space are NOT 3D.
If in doubt, say false: an unnecessary 3D model distracts and can teach something wrong.
If you do build one: at least two distinct solids, at least two labelled parts, every step reveals a new part, and the arrangement must be faithful
to the real thing (sizes, counts, positions, and what stays together or separates) — a model that shows the wrong arrangement is worse than none.

${VOCABULARY_3D}

${STEPS_SPEC}

${PERSONA_RULES}

${TRUTH_RULES}

${languageRules(age)}

Return ONLY JSON, one of:
{"useful": false, "reason": "<one sentence>"}
{"useful": true, "reason": "<one sentence>", "visual": {"dim":"3d","title":"...","purpose":"teach","representation":"visual_diagram",
  "why":"...","frame":{"kind":"space",...},"elements":[...],"steps":[...],"checkQuestion":"<question ending in ?>"}}`;
  }

  let task: string;
  if (req.purpose === 'teach') {
    task = `TASK: draw ${req.focus && req.focus.trim().toLowerCase() !== ctx.topic.trim().toLowerCase() ? `the picture for this part of the lesson: "${req.focus}"` : 'the MAIN teaching picture for this concept'} — the one the tutor builds while first explaining it.${keyFactScope(ctx, req.keyFacts)}
  • It must make the key fact(s) visible. If a known misconception exists, the finished picture should contain the
    evidence that quietly contradicts it (without calling anything wrong) — the tutor will point at it.
  • ${req.representation ? (req.representation.idea ? `Realise EXACTLY this representation (${req.representation.strategy}): "${req.representation.idea}". Do not substitute a different one.` : `Use a ${req.representation.strategy} style of representation, but draw ONLY the key fact(s) listed above. The authored representation ideas above were written for the concept's FIRST picture — do not redraw them here; this picture must teach its own key fact(s).`) : 'Realise the best-fitting authored representation idea above when there is one.'}
  • Build the idea so the learner could work out the rule from what is drawn, not just read it.
  • Phases: step 1 "hook" (a question), middle steps "teach", last step "check" (asks the checkQuestion).`;
  } else if (req.purpose === 'contrast') {
    const m = req.misconception;
    task = `TASK: draw a CONTRAST CASE. The tutor shows this picture when the learner seems to believe:
    "${m.belief}"${m.triggerPattern ? `\n  (it shows up as: ${m.triggerPattern})` : ''}${m.probeQuestion ? `\n  The tutor's probe question: "${m.probeQuestion}"` : ''}${m.correctionHint ? `\n  What should become clear: ${m.correctionHint}` : ''}
  Build it in exactly this order:
    1. "teach": set up one concrete case where the rule can be tested, with real numbers or a real drawn example;
    2. "contrast": APPLY THE LEARNER'S RULE to that case, step by step, using its own working — draw or write the actual working
       (for example the sum done their way) — so the clash is visible: the result does not match what is drawn or what is true.
       The working itself must be computed correctly. Do not just write "this fails" or "impossible": show it;
    3. "teach": the rule that does work, applied to the same case, in the same picture;
    4. "check": a caption that asks the learner to explain the difference in their own words (ends in "?").
  Captions test the rule ("Let's test this rule"), never judge the learner, and never label the rule with "Mistaken", "Wrong" or a cross. Set "purpose":"contrast".`;
  } else {
    task = `TASK: draw an APPLICATION picture. The learner has been taught the idea and will now apply it to:
    "${req.item.prompt}"
  Draw the SITUATION of this problem — only the information the problem gives — so the learner can reason from it.
  The picture must NOT contain: the answer, any intermediate result, the graph or diagram that solves it, a list of parts already put in the right order,
  or any caption hinting which method to use ("make the coefficients match", "add the equations"). The learner chooses the method.
  What it may contain: the givens as the problem states them (numbers, objects, quantities, labelled unknowns shown as "?").
  Steps: show the situation in 1–2 steps (phase "hook" or "teach"); the final step (phase "apply") asks the question of the problem in its caption, ending in "?".
  Set "purpose":"apply". (For your own guidance only, a sound answer contains: ${req.item.lookFor || 'the learner works it out'} — never draw or write any of it.)`;
  }

  return `${header}

${conceptBlock(ctx)}

${task}
${req.form === 'worked' ? `\nFORM: this board is a WORKED board — a step-by-step working laid out on the board (equations, small tables, annotated lines, each line appearing in its own step). Text and equation bricks are the point here, so the "mostly drawn" preference does not apply; still keep every brick short, one line per idea, and never write the final answer of a learner-facing question.\n` : ''}
${VOCABULARY_2D}

${STEPS_SPEC}

${PERSONA_RULES}

${TRUTH_RULES}

${languageRules(age)}

${OUTPUT_2D}`;
}

export interface RepairProblem { message: string; where?: string }

/** Second attempt: hand the checkers' findings back to the model. */
export function buildRepairPrompt(previousJson: string, issues: RepairProblem[], dim: '2d' | '3d'): string {
  const problems = issues.map((i) => `  - ${i.where ? i.where + ': ' : ''}${i.message}`).join('\n');
  return `You drew this board picture for a school lesson:
${previousJson}

Automatic checkers and an independent reviewer examined it and found:
${problems}

Fix each problem — change the geometry or change the label so every stated fact is exactly true, remove anything that gives away an answer,
add the missing question, draw what a label promises — and keep everything else that was right (the steps, the teaching order, the ids).
Do not introduce new problems: the same checks will run again.
${dim === '3d' ? VOCABULARY_3D : VOCABULARY_2D}

${STEPS_SPEC}

${PERSONA_RULES}

Return ONLY the corrected JSON in exactly the same format${dim === '3d' ? ' (the visual object itself, with "dim":"3d")' : ''}.`;
}

// ─── planning: one idea per picture (decision D8) ─────────────────

export interface PicturePlanItem { focus: string; keyFacts: number[] }

export function buildPlannerPrompt(ctx: VisualConceptContext, maxPictures: number): string {
  return `You plan the teaching pictures for one concept for a ${ageFor(ctx.grade)}. Each picture teaches ONE idea, built step by step on a board.

${conceptBlock(ctx)}

Group the key facts into at most ${maxPictures} pictures.
  • A picture covers 1 or 2 key facts — 2 only when they cannot be understood apart.
  • Every key fact belongs to exactly one picture; keep them in teaching order; the first picture is the foundation the others build on.
  • "focus" is a short label (2–6 words) for the idea, as a tutor would say it ("the vertical line x = a").
  • Each key fact must be something a picture can SHOW (a structure, a process, a comparison, a graph); if a fact is purely a definition, group it with the picture it defines.

Return ONLY JSON: {"pictures":[{"focus":"<2-6 words>","keyFacts":[<key fact numbers>]}]}`;
}

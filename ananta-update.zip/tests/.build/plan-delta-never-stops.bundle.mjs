// src/plan/delta.ts
function initialDeltaState() {
  return { retryCountByConcept: {}, consecutiveFailures: 0, consecutiveChecksWithoutTeach: 0, probesUsedByQuestion: {} };
}
function deriveOutcome(input) {
  if (input.candidateMisconceptionsCount > 0) {
    return input.newlyConfirmedCount > 0 ? "misconception_confirmed" : "misconception_suspected";
  }
  if (input.classification === "misconception_behind_correct") return "misconception_suspected";
  if (input.classification === "wrong_answer" || input.classification === "needs_clarification") return "failed_check";
  return "sound";
}
function compilePlanDelta(plan, state, event) {
  const next = {
    retryCountByConcept: { ...state.retryCountByConcept },
    consecutiveFailures: state.consecutiveFailures,
    consecutiveChecksWithoutTeach: state.consecutiveChecksWithoutTeach,
    probesUsedByQuestion: { ...state.probesUsedByQuestion }
  };
  switch (event.outcome) {
    case "sound":
    case "mastered": {
      next.consecutiveFailures = 0;
      next.retryCountByConcept[event.conceptId] = 0;
      return { instruction: event.outcome === "mastered" ? "Method is sound and mastery evidence is strong \u2014 move to transfer or the next concept." : "Method is sound \u2014 continue teaching or check the next chunk.", state: next };
    }
    case "failed_check": {
      const retries = (next.retryCountByConcept[event.conceptId] || 0) + 1;
      next.retryCountByConcept[event.conceptId] = retries;
      next.consecutiveFailures += 1;
      const order = plan.representationOrder.map((r) => r.strategy);
      const avoided = new Set(plan.avoidRepresentations.map((a) => a.strategy));
      const idx = order.indexOf(event.representationUsed);
      const nextRep = order.slice(idx + 1).find((r) => !avoided.has(r)) || order.find((r) => r !== event.representationUsed && !avoided.has(r));
      const repText = nextRep ? nextRep.replace(/_/g, " ") : "a different representation than the last one used";
      if (retries >= plan.limits.retryCap) {
        return {
          instruction: `Several misses in a row on this idea, so questioning is not working \u2014 TEACH it directly now. Do not ask another question until you have explained. Use ${repText}: a fully worked example of a PARALLEL problem, one small step at a time, using the board, saying the reasoning aloud. Then ask ONE much smaller question that covers only the first step. Stay warm and matter-of-fact. Do NOT end or pause the session, do NOT say you will come back later, and do NOT mention teachers or parents.`,
          nextRepresentation: nextRep,
          teachDirectly: true,
          state: next
        };
      }
      if (next.consecutiveFailures >= 2) {
        return {
          instruction: `Two misses in a row \u2014 the last approach is not landing. Normalise it briefly ("this one is tricky at first"), then STOP asking questions and TEACH: explain the idea again using ${repText}, with a worked example on the board. Only after that ask one smaller question. Do NOT repeat the earlier explanation, do NOT just re-ask with new numbers, and do NOT pause or defer.`,
          nextRepresentation: nextRep,
          teachDirectly: true,
          encourageReset: true,
          state: next
        };
      }
      if (!event.hasReasoning) {
        return {
          instruction: `That answer is not right, but do not tell them so yet and do NOT ask a new question. Ask, warmly and neutrally, how they got it \u2014 e.g. "Walk me through how you got that." Then wait for their answer. After they explain (or say they are not sure), you will explain the idea a different way.`,
          nextRepresentation: nextRep,
          state: next
        };
      }
      return {
        instruction: `They have now told you their thinking. Name, kindly, the one step in THEIR reasoning that goes off track (evaluate the method, never the person), then EXPLAIN the idea using ${repText} with a short worked example \u2014 do NOT repeat the earlier explanation and do NOT just ask another question with new numbers. Only after explaining, ask one fresh check question and wait.`,
        nextRepresentation: nextRep,
        teachDirectly: true,
        state: next
      };
    }
    case "misconception_suspected": {
      const key = event.questionKey || event.conceptId;
      const used = (next.probesUsedByQuestion[key] || 0) + 1;
      next.probesUsedByQuestion[key] = used;
      if (used > plan.limits.probeBudget) {
        return { instruction: "Probe budget used up for this question \u2014 stop probing and teach with a new representation instead.", state: next };
      }
      return { instruction: "A misconception is suspected but not yet confirmed \u2014 ask ONE discriminating probe. No hints, no answer, then silence.", state: next };
    }
    case "misconception_confirmed": {
      return { instruction: "Misconception CONFIRMED. Use a contrast case: show where their rule works and where it breaks. Then re-test with a transfer item, never the same question again.", state: next };
    }
    case "frustration_signal": {
      next.consecutiveFailures = 0;
      return { instruction: "Frustration or fatigue signal \u2014 normalise it and shrink the step, then keep teaching with a simpler example. Offer a short break only if the learner asks for one.", encourageReset: true, state: next };
    }
    case "language_error": {
      return { instruction: "This looks like a language/reading issue, not a concept gap \u2014 rephrase with simpler words or a visual. Do not record this as a concept error.", state: next };
    }
    default:
      return { instruction: "Continue.", state: next };
  }
}
export {
  compilePlanDelta,
  deriveOutcome,
  initialDeltaState
};

// tests/genai-stub.mjs
var GoogleGenAI = class {
  constructor() {
    this.models = { generateContent: async (req) => {
      const S = globalThis.STUB;
      S.calls.push({ model: req.model, thinking: !!req.config?.thinkingConfig });
      const rule = S.models[req.model];
      if (!rule) throw new Error(`models/${req.model} is not found`);
      if (rule.rejectThinking && req.config?.thinkingConfig) throw new Error("thinking_level is not supported for this model");
      await new Promise((r) => setTimeout(r, rule.delay));
      return { text: JSON.stringify({
        classification: "misconception_behind_correct",
        understandingDepth: "memorised",
        candidateMisconceptionIds: ["finding-hypotenuse::m1", "bogus::id"],
        confidence: "high",
        reasoningSummary: "added the sides",
        shouldProbe: true,
        probeQuestion: "What does your method give for 6 and 8?",
        nextStrategy: "worked_example",
        tutorGuidance: "Ask the probe."
      }) };
    } };
  }
};

// src/adaptive/assessmentEngine.ts
var STRATEGY_DESCRIPTIONS = {
  direct_explanation: "Explain the concept clearly and directly with definitions and rules",
  worked_example: "Walk through a complete solved example step by step",
  visual_diagram: "Use a visual diagram or spatial representation on the blackboard",
  real_world_analogy: "Connect the concept to something familiar in everyday life",
  socratic_questioning: "Ask guiding questions to lead the student to discover the answer",
  step_by_step: "Break the problem into very small numbered steps",
  story_context: "Embed the concept inside a short story or narrative",
  interactive_simulation: "Let the student manipulate variables and observe outcomes",
  peer_comparison: "Compare with a concept the student already understands well",
  prerequisite_review: "Step back and revisit the foundational concept this depends on"
};

// src/adaptive/reasoningAssessor.ts
var REASONING_MODEL_CANDIDATES = ["gemini-3.6-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"];
var resolvedModel = null;
var failedModels = /* @__PURE__ */ new Set();
var noThinkingConfig = /* @__PURE__ */ new Set();
function misconceptionCatalog(concept) {
  const details = concept.misconceptionDetails || [];
  if (details.length && details.every((d) => d.id)) {
    return details.map((d) => ({ id: `${concept.id}::${d.id}`, text: d.belief }));
  }
  return concept.commonMisconceptions.map((text, i) => ({
    id: `${concept.id}::m${i + 1}`,
    text
  }));
}
function misconceptionText(concept, id) {
  return misconceptionCatalog(concept).find((m) => m.id === id)?.text;
}
function correctAnswerTrap(mode) {
  if (mode === "interpretive") {
    return `A correct-sounding conclusion is NOT evidence of understanding. Ask yourself explicitly:
"Is this claim actually supported by evidence and reasoning the child gave, or did they
repeat a conclusion they have heard?" If the reasoning would not hold up for a different
source or case, it is misconception_behind_correct, even though the conclusion sounds right.`;
  }
  if (mode === "skill") {
    return `A correct form is NOT evidence of understanding. Ask yourself explicitly:
"Would the child produce the right form again in a different sentence or context, or did
they recognise/copy it?" If the rule they describe would fail elsewhere, it is
misconception_behind_correct, even though this answer was right.`;
  }
  return `A correct final answer is NOT evidence of understanding. Ask yourself explicitly:
"Would this exact method still produce the right answer if the numbers, the orientation
or the context of the problem changed?" If no, it is misconception_behind_correct,
even though the child was right. This is the single most important judgement you make.`;
}
function buildPrompt(input) {
  const { concept, conceptState, questionAsked, childAnswer, childReasoning, expectedAnswer, currentStrategy } = input;
  const catalog = misconceptionCatalog(concept);
  const catalogText = catalog.map((m) => `  ${m.id} \u2014 ${m.text}`).join("\n");
  const alreadySuspected = conceptState?.suspectedMisconceptions.join("; ") || "none";
  const alreadyConfirmed = conceptState?.confirmedMisconceptions.join("; ") || "none";
  const ineffective = conceptState?.ineffectiveStrategies.join(", ") || "none";
  const age = input.gradeLevel ? `${input.gradeLevel + 5}-year-old` : "13-year-old";
  const subject = input.subjectLabel ? input.subjectLabel.toLowerCase() : "mathematics";
  return `You are a diagnostic assessor for a ${age}'s ${subject} tutor. You are NOT the tutor. You do not talk to the child. You analyse one exchange and return JSON.

CONCEPT: ${concept.label} (difficulty ${concept.difficultyLevel}/5)
KEY FACTS:
${concept.keyFacts.map((f) => `  - ${f}`).join("\n")}

THE EXCHANGE
  Tutor asked:        "${questionAsked}"
  Expected answer:    "${expectedAnswer || "(open-ended \u2014 judge on the reasoning)"}"
  Child answered:     "${childAnswer}"
  Child's reasoning:  "${childReasoning || "(the child gave no reasoning)"}"

CLOSED MISCONCEPTION CATALOGUE for this concept \u2014 you may ONLY select ids from this list:
${catalogText}

LEARNER HISTORY
  Already suspected: ${alreadySuspected}
  Already confirmed: ${alreadyConfirmed}
  Strategies that did NOT help: ${ineffective}
  Strategy currently in use: ${currentStrategy}

CLASSIFY into exactly one of:
  "clear_reasoning"              answer correct AND the method is sound and articulated
  "needs_clarification"          answer correct but the method is too thin to judge
  "misconception_behind_correct" answer correct but the method is WRONG or would fail on a variant
  "wrong_answer"                 answer is incorrect
  "no_reasoning_given"           the child gave an answer with no method at all

CRITICAL INSTRUCTION \u2014 THE CORRECT ANSWER TRAP:
${correctAnswerTrap(input.subjectMode)}

FALSE-POSITIVE DISCIPLINE:
Do not select a misconception id from one ambiguous utterance. If the reasoning is
merely brief or vague, that is "needs_clarification" with shouldProbe=true and NO
misconception ids. Only select ids when the child's own words positively indicate
that specific error. Prefer an empty list over a guess.

PROBE DESIGN:
When shouldProbe is true, write ONE short spoken question that DISCRIMINATES between
the candidate misconceptions \u2014 a question the child answers differently depending on
which error they hold. Never a question that reveals the answer. Never more than one
sentence. Vocabulary for a ${age}.

Return ONLY valid JSON, no markdown fences:
{
  "classification": "clear_reasoning|needs_clarification|misconception_behind_correct|wrong_answer|no_reasoning_given",
  "understandingDepth": "memorised|recognised|understood|applied|transferred|incorrect|guessed|confused",
  "candidateMisconceptionIds": ["exact ids from the catalogue, or empty"],
  "confidence": "high|medium|low",
  "reasoningSummary": "the child's method in one plain sentence, written so it can be shown back to them on the board",
  "faultyStep": "the single step that is wrong, or null",
  "shouldProbe": true|false,
  "probeQuestion": "one discriminating question, or null",
  "probeRationale": "what each possible reply would tell you, or null",
  "nextStrategy": "${Object.keys(STRATEGY_DESCRIPTIONS).join("|")}",
  "tutorGuidance": "ONE imperative sentence telling the tutor what to do on its very next turn"
}

RULES FOR tutorGuidance:
- If shouldProbe: it must instruct the tutor to ASK the probe and NOT to reveal the answer.
- Never instruct the tutor to say the child is wrong. Instruct it to test the METHOD.
- If classification is clear_reasoning: instruct specific process praise naming the exact
  correct move the child made, then advance.
- Never suggest a strategy listed as ineffective above.`;
}
var VALID_DEPTHS = [
  "memorised",
  "recognised",
  "understood",
  "applied",
  "transferred",
  "incorrect",
  "guessed",
  "confused"
];
async function assessReasoning(input) {
  const catalogIds = new Set(misconceptionCatalog(input.concept).map((m) => m.id));
  try {
    const ai = new GoogleGenAI({
      apiKey: input.apiKey,
      httpOptions: { headers: { "User-Agent": "aistudio-build" } }
    });
    let text = "";
    const order = [
      ...resolvedModel ? [resolvedModel] : [],
      ...REASONING_MODEL_CANDIDATES.filter((m) => m !== resolvedModel && !failedModels.has(m))
    ];
    for (const model of order) {
      for (let attempt = 0; attempt < 2 && !text; attempt++) {
        const useThinking = !noThinkingConfig.has(model);
        const t0 = Date.now();
        try {
          const response = await ai.models.generateContent({
            model,
            contents: buildPrompt(input),
            config: {
              responseMimeType: "application/json",
              // Diagnosis is a classification task, not a hard reasoning one.
              // Low thinking keeps it inside the conversational latency budget.
              ...useThinking ? { thinkingConfig: { thinkingLevel: "low" } } : {}
            }
          });
          text = response.text || "";
          if (text) {
            if (resolvedModel !== model) console.log(`[ReasoningAssessor] using ${model}`);
            resolvedModel = model;
            console.log(`[ReasoningAssessor] ${model} answered in ${Date.now() - t0}ms`);
          }
        } catch (modelErr) {
          const msg = String(modelErr?.message || modelErr);
          if (useThinking && /thinking/i.test(msg)) {
            noThinkingConfig.add(model);
            console.warn(`[ReasoningAssessor] ${model} rejected thinkingConfig; retrying without`);
            continue;
          }
          failedModels.add(model);
          console.warn(`[ReasoningAssessor] ${model} failed and will be skipped: ${msg.slice(0, 160)}`);
          break;
        }
      }
      if (text) break;
    }
    if (!text) throw new Error("no model returned a response");
    const parsed = JSON.parse(text.replace(/```json\s*|\s*```/g, "").trim());
    const ids = Array.isArray(parsed.candidateMisconceptionIds) ? parsed.candidateMisconceptionIds.filter((id) => typeof id === "string" && catalogIds.has(id)) : [];
    const depth = VALID_DEPTHS.includes(parsed.understandingDepth) ? parsed.understandingDepth : "confused";
    const classification = [
      "clear_reasoning",
      "needs_clarification",
      "misconception_behind_correct",
      "wrong_answer",
      "no_reasoning_given"
    ].includes(parsed.classification) ? parsed.classification : "needs_clarification";
    const shouldProbe = classification === "clear_reasoning" ? false : parsed.shouldProbe !== false;
    const nextStrategy = parsed.nextStrategy in STRATEGY_DESCRIPTIONS ? parsed.nextStrategy : "socratic_questioning";
    return {
      classification,
      understandingDepth: depth,
      candidateMisconceptionIds: ids,
      confidence: ["high", "medium", "low"].includes(parsed.confidence) ? parsed.confidence : "low",
      reasoningSummary: String(parsed.reasoningSummary || input.childReasoning || input.childAnswer || ""),
      faultyStep: parsed.faultyStep || void 0,
      shouldProbe,
      probeQuestion: parsed.probeQuestion || void 0,
      probeRationale: parsed.probeRationale || void 0,
      nextStrategy,
      tutorGuidance: String(parsed.tutorGuidance || fallbackGuidance(classification))
    };
  } catch (err) {
    console.error("[ReasoningAssessor] failed, using safe fallback:", err);
    return safeFallback(input);
  }
}
function fallbackGuidance(c) {
  if (c === "clear_reasoning") return "Name the specific correct move the child made, then move to the next idea.";
  return "Do NOT give the answer. Ask the child to walk you through how they worked it out, one step at a time.";
}
function safeFallback(input) {
  const hasReasoning = Boolean(input.childReasoning && input.childReasoning.trim().length > 12);
  return {
    classification: hasReasoning ? "needs_clarification" : "no_reasoning_given",
    understandingDepth: "confused",
    candidateMisconceptionIds: [],
    confidence: "low",
    reasoningSummary: input.childReasoning || input.childAnswer || "",
    shouldProbe: true,
    probeQuestion: "Talk me through how you got that \u2014 what did you work out first?",
    probeRationale: "Assessment unavailable; eliciting the method directly.",
    nextStrategy: "socratic_questioning",
    tutorGuidance: "Do NOT give the answer. Ask the child to talk you through their working, starting with the first step."
  };
}
async function assessReasoningWithDeadline(input, budgetMs = 6500) {
  const t0 = Date.now();
  const full = assessReasoning(input);
  let timer;
  const deadline = new Promise((resolve) => {
    timer = setTimeout(() => resolve(null), budgetMs);
  });
  const winner = await Promise.race([full, deadline]);
  if (timer) clearTimeout(timer);
  const elapsedMs = Date.now() - t0;
  if (winner) return { assessment: winner, timedOut: false, full, elapsedMs };
  return { assessment: transferMove(input), timedOut: true, full, elapsedMs };
}
function transferMove(input) {
  return {
    classification: "needs_clarification",
    understandingDepth: "recognised",
    candidateMisconceptionIds: [],
    confidence: "low",
    reasoningSummary: input.childReasoning || input.childAnswer || "",
    shouldProbe: true,
    probeQuestion: void 0,
    probeRationale: "Assessment still running; a transfer item discriminates a sound method from a broken one on its own.",
    nextStrategy: input.currentStrategy,
    tutorGuidance: input.childReasoning && input.childReasoning.trim().length > 3 ? "Use their own words: name the one step in their thinking that goes off track, then explain the idea a different way with a short worked example, and only then ask a fresh check question. Do NOT just ask again with different numbers." : 'Ask warmly how they got that ("Walk me through how you got that") and wait. Do NOT give new numbers and do NOT ask a new question until you understand their thinking, then explain the idea a different way.'
  };
}
export {
  assessReasoning,
  assessReasoningWithDeadline,
  misconceptionCatalog,
  misconceptionText
};

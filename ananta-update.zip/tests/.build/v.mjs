// src/guided/types.ts
var BEAT_KINDS = [
  "orient",
  // where this sits, what we are about to do
  "define",
  // what it is (and what it is not)
  "show",
  // build the picture / working step by step
  "analogy",
  // something familiar
  "contrast",
  // a non-example, or a common mix-up, side by side
  "rule",
  // the rule, in one line
  "exception",
  // where the rule needs care
  "method",
  // the procedure, worked
  "apply",
  // the child tries a fresh one
  "check"
  // closing question
];

// src/guided/validate.ts
var LIMITS = {
  minBeats: 6,
  maxBeats: 12,
  maxItemsPerBeat: 6,
  maxItemsTotal: 30,
  maxLineChars: 90,
  maxHeadingChars: 48,
  maxSayChars: 700,
  maxLinesPerBeat: 14,
  maxLineSayChars: 320
};
function textOf(item) {
  switch (item.type) {
    case "heading":
    case "point":
    case "rule":
    case "exception":
      return [item.text];
    case "compare":
      return [item.text, item.title ?? ""];
    case "work":
      return item.lines;
    case "slot":
      return [item.label];
    case "line":
    case "aside":
      return [item.text];
    default:
      return [];
  }
}
var numbersIn = (t) => t.match(/\d+(?:\.\d+)?/g) ?? [];
var OPS = "+-\u2212\xD7\xF7*/^";
var isSignedResult = (part) => /^[−-]?\d+(?:\.\d+)?\s*(?:%|°|[a-zA-Zµ]{1,4}[²³]?)?\.?$/.test(part.trim());
function operandsIn(seg) {
  const out = [];
  const re = /(?<![\w.])(\d+(?:\.\d+)?)(?![\w.]|\.\d)/g;
  let m;
  while (m = re.exec(seg)) {
    const before = seg.slice(0, m.index).replace(/[\s(]+$/, "");
    const after = seg.slice(m.index + m[0].length).replace(/^[\s)]+/, "");
    let opBefore = false;
    if (before && OPS.includes(before[before.length - 1])) {
      const lhs = before.slice(0, -1).trimEnd();
      opBefore = !!lhs && /[\w)%°]$/.test(lhs);
    }
    const opAfter = !!after && OPS.includes(after[0]) && after.slice(1).trim().length > 0;
    if (opBefore || opAfter) out.push(m[1]);
  }
  return out;
}
function untracedNumbers(line, seenBefore) {
  if (!line.includes("=")) return [];
  const parts = line.split("=");
  const startsFromNumber = /(?<![\w.])\d/.test(parts[0]);
  const checked = (startsFromNumber ? parts.slice(0, -1) : parts).filter((p) => !isSignedResult(p));
  return checked.flatMap(operandsIn).filter((x) => !seenBefore.has(x));
}
function validateScript(script, opts = {}) {
  const errors = [];
  const warnings = [];
  const err = (m) => errors.push(m);
  const warn = (m) => warnings.push(m);
  if (!script || script.version !== 1) {
    err("version must be 1");
    return { errors, warnings };
  }
  if (!script.conceptId) err("conceptId missing");
  if (opts.expectedConceptId && script.conceptId !== opts.expectedConceptId) err(`conceptId "${script.conceptId}" does not match the file's concept`);
  if (!script.title?.trim()) err("title missing");
  if (!Array.isArray(script.beats)) {
    err("beats must be a list");
    return { errors, warnings };
  }
  const n = script.beats.length;
  if (n < LIMITS.minBeats || n > LIMITS.maxBeats) err(`needs ${LIMITS.minBeats}\u2013${LIMITS.maxBeats} beats, has ${n}`);
  if (script.beats[0] && script.beats[0].kind !== "orient") err('the first beat must be "orient"');
  if (!script.beats.some((b) => b.kind === "rule" || b.board?.some((i) => i.type === "rule") || b.lines?.some((l) => l.style === "rule"))) err('the lesson states no rule (needs a "rule" beat, a rule item or a rule line)');
  if (!script.beats.some((b) => b.ask || b.lines?.some((l) => l.ask))) err("no beat asks the learner anything");
  const beatIds = /* @__PURE__ */ new Set();
  const slotIds = /* @__PURE__ */ new Set();
  let total = 0;
  script.beats.forEach((b, i) => {
    const at = `beat ${i + 1} (${b.id})`;
    if (!b.id || beatIds.has(b.id)) err(`${at}: id missing or duplicated`);
    beatIds.add(b.id);
    if (!BEAT_KINDS.includes(b.kind)) err(`${at}: unknown kind "${b.kind}"`);
    if (!b.say?.trim()) err(`${at}: "say" is empty`);
    else if (b.say.length > LIMITS.maxSayChars) warn(`${at}: "say" is ${b.say.length} chars (limit ${LIMITS.maxSayChars})`);
    if (!Array.isArray(b.board) || b.board.length === 0 && !b.lines?.length) err(`${at}: nothing is written on the board`);
    const items = b.board ?? [];
    total += items.length;
    if (items.length > LIMITS.maxItemsPerBeat) err(`${at}: ${items.length} board items (limit ${LIMITS.maxItemsPerBeat})`);
    const pictures = items.filter((x) => x.type === "picture");
    if (pictures.length > 1) err(`${at}: more than one picture`);
    let lastSide = null;
    items.forEach((it, k) => {
      for (const t of textOf(it)) {
        if (it.type === "heading") {
          if (t.length > LIMITS.maxHeadingChars) warn(`${at} item ${k + 1}: heading is ${t.length} chars`);
        } else if (t.length > LIMITS.maxLineChars) warn(`${at} item ${k + 1}: line is ${t.length} chars (limit ${LIMITS.maxLineChars})`);
        if (/\b(always|never)\b/i.test(t)) warn(`${at} item ${k + 1}: "${t.slice(0, 40)}\u2026" uses always/never \u2014 check it is true without exceptions`);
        if (it.type !== "slot" && it.type !== "compare" && !t.trim() && it.type !== "work") err(`${at} item ${k + 1}: empty text`);
      }
      if (it.type === "compare") {
        if (lastSide === it.side) warn(`${at} item ${k + 1}: two "${it.side}" compare items in a row`);
        lastSide = it.side;
      } else lastSide = null;
      if (it.type === "slot") {
        if (!it.id || slotIds.has(it.id)) err(`${at}: slot id missing or duplicated`);
        slotIds.add(it.id);
      }
      if (it.type === "picture" && opts.pictures) {
        const pic = opts.pictures[it.ref];
        if (!pic) err(`${at}: picture "${it.ref}" does not exist in the stored pictures`);
        else if (it.step && it.step !== "all" && !(pic.steps ?? []).some((s) => s.id === it.step)) {
          err(`${at}: picture "${it.ref}" has no step "${it.step}"`);
        }
      }
    });
    if (b.lines) checkLines(b.lines, items, at, err, warn);
    for (const l of b.lines ?? []) {
      if (l.picture && opts.pictures) {
        const pic = opts.pictures[l.picture.ref];
        if (!pic) err(`${at} line ${l.id}: picture "${l.picture.ref}" does not exist in the stored pictures`);
        else if (l.picture.step && l.picture.step !== "all" && !(pic.steps ?? []).some((s) => s.id === l.picture.step)) err(`${at} line ${l.id}: picture "${l.picture.ref}" has no step "${l.picture.step}"`);
      }
    }
    if (b.lines?.length && b.ask) err(`${at}: a line-by-line beat asks on its lines, not on the beat`);
    total += b.lines?.length ?? 0;
    if (b.ask && items.some((x) => x.type === "work")) {
      warn(`${at}: worked lines are written together with the question - the answer may be visible before the learner replies (use a line-by-line beat)`);
    }
    if (b.ask) {
      if (!b.ask.prompt?.trim()) err(`${at}: ask has no prompt`);
      if (!b.ask.lookFor?.trim()) err(`${at}: ask has no lookFor`);
      if (!b.ask.onMiss?.trim()) err(`${at}: ask has no onMiss`);
      if (b.ask.slot) {
        const hasSlot = items.some((x) => x.type === "slot" && x.id === b.ask.slot);
        if (!hasSlot) err(`${at}: ask.slot "${b.ask.slot}" is not a slot on this beat's board`);
      }
    }
  });
  if (total > LIMITS.maxItemsTotal) warn(`board has ${total} items in total (limit ${LIMITS.maxItemsTotal}) \u2014 it will be crowded`);
  const asks = script.beats.filter((b) => b.ask || b.lines?.some((l) => l.ask)).length;
  if (asks < 3) warn(`only ${asks} beats ask the learner something`);
  return { errors, warnings };
}
function checkLines(lines, boardItems, at, err, warn) {
  if (lines.length === 0) {
    err(`${at}: "lines" is empty`);
    return;
  }
  if (lines.length > LIMITS.maxLinesPerBeat) err(`${at}: ${lines.length} lines (limit ${LIMITS.maxLinesPerBeat})`);
  const ids = /* @__PURE__ */ new Set();
  const seen = new Set(boardItems.flatMap(textOf).flatMap(numbersIn));
  lines.forEach((l, k) => {
    const where = `${at} line ${k + 1} (${l.id})`;
    if (!l.id || ids.has(l.id)) err(`${where}: id missing or duplicated`);
    ids.add(l.id);
    if (!l.text?.trim()) err(`${where}: empty text`);
    else if (l.text.length > LIMITS.maxLineChars) warn(`${where}: line is ${l.text.length} chars (limit ${LIMITS.maxLineChars})`);
    if (!l.say?.trim()) err(`${where}: "say" is empty - the tutor must say every line it writes`);
    else if (l.say.length > LIMITS.maxLineSayChars) warn(`${where}: "say" is ${l.say.length} chars (limit ${LIMITS.maxLineSayChars})`);
    if (l.ask) {
      if (!l.ask.prompt?.trim() || !l.ask.lookFor?.trim() || !l.ask.onMiss?.trim()) err(`${where}: ask needs prompt, lookFor and onMiss`);
    }
    const missing = (l.style ?? "work") === "work" ? untracedNumbers(l.text ?? "", seen) : [];
    if (missing.length) err(`${where}: "${l.text}" uses ${missing.join(", ")} which is not written on any line above it - a step is missing`);
    numbersIn(l.text ?? "").forEach((x) => seen.add(x));
  });
}
export {
  LIMITS,
  untracedNumbers,
  validateScript
};

// src/ai/gateway.ts
import { GoogleGenAI } from "@google/genai";
function isQuotaError(err) {
  const msg = String(err?.message ?? err?.status ?? err?.code ?? "");
  return /\b402\b|prepay|credits? (are )?depleted|exceeded your current quota|quota exceeded|per ?day|billing/i.test(msg);
}
var QUOTA_COOLDOWN_MS = 10 * 6e4;

// src/guided/types.ts
var BEAT_KINDS = [
  "orient",
  // where this sits, what we are about to do
  "define",
  // what it is (and what it is not)
  "show",
  // build the picture / working step by step
  "analogy",
  // something familiar
  "contrast",
  // a non-example, or a common mix-up, side by side
  "rule",
  // the rule, in one line
  "exception",
  // where the rule needs care
  "method",
  // the procedure, worked
  "apply",
  // the child tries a fresh one
  "check"
  // closing question
];

// src/guided/validate.ts
var LIMITS = {
  minBeats: 6,
  maxBeats: 12,
  maxItemsPerBeat: 6,
  maxItemsTotal: 30,
  maxLineChars: 90,
  maxHeadingChars: 48,
  maxSayChars: 700,
  maxLinesPerBeat: 14,
  maxLineSayChars: 320
};
function textOf(item) {
  switch (item.type) {
    case "heading":
    case "point":
    case "rule":
    case "exception":
      return [item.text];
    case "compare":
      return [item.text, item.title ?? ""];
    case "work":
      return item.lines;
    case "slot":
      return [item.label];
    case "line":
    case "aside":
      return [item.text];
    default:
      return [];
  }
}
var numbersIn = (t) => t.match(/\d+(?:\.\d+)?/g) ?? [];
var OPS = "+-\u2212\xD7\xF7*/^";
var isSignedResult = (part) => /^[−-]?\d+(?:\.\d+)?\s*(?:%|°|[a-zA-Zµ]{1,4}[²³]?)?\.?$/.test(part.trim());
function operandsIn(seg) {
  const out = [];
  const re = /(?<![\w.])(\d+(?:\.\d+)?)(?![\w.]|\.\d)/g;
  let m;
  while (m = re.exec(seg)) {
    const before = seg.slice(0, m.index).replace(/[\s(]+$/, "");
    const after = seg.slice(m.index + m[0].length).replace(/^[\s)]+/, "");
    let opBefore = false;
    if (before && OPS.includes(before[before.length - 1])) {
      const lhs = before.slice(0, -1).trimEnd();
      opBefore = !!lhs && /[\w)%°]$/.test(lhs);
    }
    const opAfter = !!after && OPS.includes(after[0]) && after.slice(1).trim().length > 0;
    if (opBefore || opAfter) out.push(m[1]);
  }
  return out;
}
function untracedNumbers(line, seenBefore) {
  if (!line.includes("=")) return [];
  const parts = line.split("=");
  const startsFromNumber = /(?<![\w.])\d/.test(parts[0]);
  const checked = (startsFromNumber ? parts.slice(0, -1) : parts).filter((p) => !isSignedResult(p));
  return checked.flatMap(operandsIn).filter((x) => !seenBefore.has(x));
}
function validateScript(script, opts = {}) {
  const errors = [];
  const warnings = [];
  const err = (m) => errors.push(m);
  const warn = (m) => warnings.push(m);
  if (!script || script.version !== 1) {
    err("version must be 1");
    return { errors, warnings };
  }
  if (!script.conceptId) err("conceptId missing");
  if (opts.expectedConceptId && script.conceptId !== opts.expectedConceptId) err(`conceptId "${script.conceptId}" does not match the file's concept`);
  if (!script.title?.trim()) err("title missing");
  if (!Array.isArray(script.beats)) {
    err("beats must be a list");
    return { errors, warnings };
  }
  const n = script.beats.length;
  if (n < LIMITS.minBeats || n > LIMITS.maxBeats) err(`needs ${LIMITS.minBeats}\u2013${LIMITS.maxBeats} beats, has ${n}`);
  if (script.beats[0] && script.beats[0].kind !== "orient") err('the first beat must be "orient"');
  if (!script.beats.some((b) => b.kind === "rule" || b.board?.some((i) => i.type === "rule") || b.lines?.some((l) => l.style === "rule"))) err('the lesson states no rule (needs a "rule" beat, a rule item or a rule line)');
  if (!script.beats.some((b) => b.ask || b.lines?.some((l) => l.ask))) err("no beat asks the learner anything");
  const beatIds = /* @__PURE__ */ new Set();
  const slotIds = /* @__PURE__ */ new Set();
  let total = 0;
  script.beats.forEach((b, i) => {
    const at = `beat ${i + 1} (${b.id})`;
    if (!b.id || beatIds.has(b.id)) err(`${at}: id missing or duplicated`);
    beatIds.add(b.id);
    if (!BEAT_KINDS.includes(b.kind)) err(`${at}: unknown kind "${b.kind}"`);
    if (!b.say?.trim()) err(`${at}: "say" is empty`);
    else if (b.say.length > LIMITS.maxSayChars) warn(`${at}: "say" is ${b.say.length} chars (limit ${LIMITS.maxSayChars})`);
    if (!Array.isArray(b.board) || b.board.length === 0 && !b.lines?.length) err(`${at}: nothing is written on the board`);
    const items = b.board ?? [];
    total += items.length;
    if (items.length > LIMITS.maxItemsPerBeat) err(`${at}: ${items.length} board items (limit ${LIMITS.maxItemsPerBeat})`);
    const pictures = items.filter((x) => x.type === "picture");
    if (pictures.length > 1) err(`${at}: more than one picture`);
    let lastSide = null;
    items.forEach((it, k) => {
      for (const t of textOf(it)) {
        if (it.type === "heading") {
          if (t.length > LIMITS.maxHeadingChars) warn(`${at} item ${k + 1}: heading is ${t.length} chars`);
        } else if (t.length > LIMITS.maxLineChars) warn(`${at} item ${k + 1}: line is ${t.length} chars (limit ${LIMITS.maxLineChars})`);
        if (/\b(always|never)\b/i.test(t)) warn(`${at} item ${k + 1}: "${t.slice(0, 40)}\u2026" uses always/never \u2014 check it is true without exceptions`);
        if (it.type !== "slot" && it.type !== "compare" && !t.trim() && it.type !== "work") err(`${at} item ${k + 1}: empty text`);
      }
      if (it.type === "compare") {
        if (lastSide === it.side) warn(`${at} item ${k + 1}: two "${it.side}" compare items in a row`);
        lastSide = it.side;
      } else lastSide = null;
      if (it.type === "slot") {
        if (!it.id || slotIds.has(it.id)) err(`${at}: slot id missing or duplicated`);
        slotIds.add(it.id);
      }
      if (it.type === "picture" && opts.pictures) {
        const pic = opts.pictures[it.ref];
        if (!pic) err(`${at}: picture "${it.ref}" does not exist in the stored pictures`);
        else if (it.step && it.step !== "all" && !(pic.steps ?? []).some((s2) => s2.id === it.step)) {
          err(`${at}: picture "${it.ref}" has no step "${it.step}"`);
        }
      }
    });
    if (b.lines) checkLines(b.lines, items, at, err, warn);
    for (const l of b.lines ?? []) {
      if (l.picture && opts.pictures) {
        const pic = opts.pictures[l.picture.ref];
        if (!pic) err(`${at} line ${l.id}: picture "${l.picture.ref}" does not exist in the stored pictures`);
        else if (l.picture.step && l.picture.step !== "all" && !(pic.steps ?? []).some((s2) => s2.id === l.picture.step)) err(`${at} line ${l.id}: picture "${l.picture.ref}" has no step "${l.picture.step}"`);
      }
    }
    if (b.lines?.length && b.ask) err(`${at}: a line-by-line beat asks on its lines, not on the beat`);
    total += b.lines?.length ?? 0;
    if (b.ask && items.some((x) => x.type === "work")) {
      warn(`${at}: worked lines are written together with the question - the answer may be visible before the learner replies (use a line-by-line beat)`);
    }
    if (b.ask) {
      if (!b.ask.prompt?.trim()) err(`${at}: ask has no prompt`);
      if (!b.ask.lookFor?.trim()) err(`${at}: ask has no lookFor`);
      if (!b.ask.onMiss?.trim()) err(`${at}: ask has no onMiss`);
      if (b.ask.slot) {
        const hasSlot = items.some((x) => x.type === "slot" && x.id === b.ask.slot);
        if (!hasSlot) err(`${at}: ask.slot "${b.ask.slot}" is not a slot on this beat's board`);
      }
    }
  });
  if (total > LIMITS.maxItemsTotal) warn(`board has ${total} items in total (limit ${LIMITS.maxItemsTotal}) \u2014 it will be crowded`);
  const asks = script.beats.filter((b) => b.ask || b.lines?.some((l) => l.ask)).length;
  if (asks < 3) warn(`only ${asks} beats ask the learner something`);
  return { errors, warnings };
}
function checkLines(lines, boardItems, at, err, warn) {
  if (lines.length === 0) {
    err(`${at}: "lines" is empty`);
    return;
  }
  if (lines.length > LIMITS.maxLinesPerBeat) err(`${at}: ${lines.length} lines (limit ${LIMITS.maxLinesPerBeat})`);
  const ids = /* @__PURE__ */ new Set();
  const seen = new Set(boardItems.flatMap(textOf).flatMap(numbersIn));
  lines.forEach((l, k) => {
    const where = `${at} line ${k + 1} (${l.id})`;
    if (!l.id || ids.has(l.id)) err(`${where}: id missing or duplicated`);
    ids.add(l.id);
    if (!l.text?.trim()) err(`${where}: empty text`);
    else if (l.text.length > LIMITS.maxLineChars) warn(`${where}: line is ${l.text.length} chars (limit ${LIMITS.maxLineChars})`);
    if (!l.say?.trim()) err(`${where}: "say" is empty - the tutor must say every line it writes`);
    else if (l.say.length > LIMITS.maxLineSayChars) warn(`${where}: "say" is ${l.say.length} chars (limit ${LIMITS.maxLineSayChars})`);
    if (l.ask) {
      if (!l.ask.prompt?.trim() || !l.ask.lookFor?.trim() || !l.ask.onMiss?.trim()) err(`${where}: ask needs prompt, lookFor and onMiss`);
    }
    const missing = (l.style ?? "work") === "work" ? untracedNumbers(l.text ?? "", seen) : [];
    if (missing.length) err(`${where}: "${l.text}" uses ${missing.join(", ")} which is not written on any line above it - a step is missing`);
    numbersIn(l.text ?? "").forEach((x) => seen.add(x));
  });
}

// src/guided/generate.ts
var QuotaExhaustedError = class extends Error {
};
var s = (v, max = 900) => typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max) : "";
var arr = (v) => Array.isArray(v) ? v : [];
function sourceFromCurriculum(concept, course, record, labelOf = (id) => id) {
  const source = {
    conceptId: String(concept.id),
    label: s(concept.label, 200),
    subject: s(course?.subject || course?.label || "", 80),
    grade: s(String(course?.grade ?? course?.gradeLevel ?? ""), 40),
    keyFacts: arr(concept.keyFacts).map((x) => s(x, 600)).filter(Boolean),
    workedExamples: arr(concept.workedExamples).map((x) => s(x, 1400)).filter(Boolean),
    misconceptions: (arr(concept.misconceptionDetails).length ? arr(concept.misconceptionDetails) : arr(concept.commonMisconceptions).map((b) => ({ belief: b }))).map((m) => ({ belief: s(m.belief, 400), correctionHint: s(m.correctionHint, 400) || void 0, probeQuestion: s(m.probeQuestion, 300) || void 0 })).filter((m) => m.belief),
    representationIdeas: arr(concept.representationIdeas).map((r) => s(typeof r === "string" ? r : `${r.strategy}: ${r.idea}`, 500)).filter(Boolean),
    practice: arr(concept.ladderItems).map((l) => ({ level: l.level, prompt: s(l.prompt, 400), lookFor: s(l.lookFor, 400) || void 0 })).filter((l) => l.prompt),
    prerequisites: arr(concept.prerequisites).map((p) => labelOf(String(p)))
  };
  const pictures = [];
  const pictureRefs = {};
  for (const [key, v] of Object.entries(record?.visuals ?? {})) {
    if (!v || !Array.isArray(v.steps)) continue;
    const labelById = new Map(arr(v.elements).map((e) => [String(e.id), s(e.label || e.text || "", 80)]));
    pictures.push({
      key,
      title: s(v.title, 120),
      steps: v.steps.map((st) => ({
        id: String(st.id),
        caption: s(st.caption, 200),
        shows: arr(st.show).map((id) => labelById.get(String(id)) || "").filter(Boolean)
      }))
    });
    pictureRefs[key] = { steps: v.steps.map((st) => ({ id: String(st.id) })) };
  }
  return { source, pictures, pictureRefs };
}
var SHAPE = `{
  "version": 1,
  "conceptId": "<given>",
  "title": "<short lesson title>",
  "beats": [
    { "id": "b1", "kind": "orient", "say": "<what this beat is for, 1-2 sentences, guidance for the tutor>",
      "board": [ { "type": "heading", "text": "<max 40 chars>" } ],
      "lines": [ { "id": "l1", "text": "<what is written>", "say": "<what the tutor says as it appears>", "style": "point" } ] },
    { "id": "b2", "kind": "show", "say": "...",
      "board": [ { "type": "heading", "text": "..." }, { "type": "picture", "ref": "<picture key>", "step": "<step id>" } ],
      "lines": [
        { "id": "given", "text": "Two points:  (2, 1)  and  (2, 5)", "say": "Let's take two points on the line x = 2: two-comma-one and two-comma-five.", "style": "work" },
        { "id": "rise", "text": "rise = 5 \u2212 1 = 4", "say": "Rise is how far we go up: y goes from 1 to 5, so 5 minus 1 is 4.", "style": "work" },
        { "id": "run", "text": "run = 2 \u2212 2 = 0", "say": "Run is 2 minus 2, which is 0 - we do not move across at all.", "style": "work",
          "ask": { "prompt": "Your turn: x goes from 2 to 2. What is the run?", "lookFor": "0, because both x values are 2", "onMiss": "Point to the two x values on the board - how far across is 2 to 2?" },
          "picture": { "ref": "<picture key>", "step": "<later step id>" } },
        { "id": "rule", "text": "gradient = rise \xF7 run", "say": "...", "style": "rule" }
      ] }
  ]
}`;
function sourceBlock(src, pictures) {
  const list = (xs) => xs.length ? xs.map((x) => `  - ${x}`).join("\n") : "  (none)";
  return `CONCEPT: ${src.label}
SUBJECT: ${src.subject}    GRADE / LEVEL: ${src.grade}
conceptId: ${src.conceptId}
BUILDS ON: ${src.prerequisites.join("; ") || "(nothing listed)"}

KEY FACTS (the only facts you may teach):
${list(src.keyFacts)}

WORKED EXAMPLES (use their numbers and steps; you may split a step into smaller lines, never skip one):
${list(src.workedExamples)}

COMMON MISCONCEPTIONS:
${list(src.misconceptions.map((m) => `${m.belief}${m.correctionHint ? `  \u2192  correction: ${m.correctionHint}` : ""}`))}

REPRESENTATION IDEAS:
${list(src.representationIdeas)}

PRACTICE ITEMS (for the apply / check beats):
${list(src.practice.map((p) => `${p.prompt}${p.lookFor ? `  (look for: ${p.lookFor})` : ""}`))}

BOARD PICTURES (use ONLY these keys and step ids; a step shows everything in earlier steps too):
${pictures.length ? pictures.map((p) => `  \u2022 "${p.key}" - ${p.title}
${p.steps.map((st) => `      ${st.id}: caption "${st.caption}"${st.shows.length ? ` | shows: ${st.shows.join(", ")}` : ""}`).join("\n")}`).join("\n") : "  (none - write no picture items)"}`;
}
var METHOD = `THE METHOD (non-negotiable). Teach like the best chalkboard teacher: SAY a line, WRITE it, explain it, next line.
1. Every beat is written LINE BY LINE in "lines". "board" may hold only a heading and/or one picture, shown as the beat starts.
2. One line = one idea or one operation. Max ${LIMITS.maxLineChars - 20} characters. Never two steps in one line.
3. "say" is what the tutor says as the line appears: read the line aloud in words, then at most one sentence of why. Max 2 sentences.
4. NEVER SKIP A STEP. In working, go: what is given \u2192 unpack it (name each value) \u2192 the rule/formula in words \u2192 substitute \u2192 calculate \u2192 what it means.
   Every number used on a line with "=" must already be written on a line ABOVE it in the same beat (only the final result after the last "=" may be new).
5. INTERACTIVE: at least 4 lines across the lesson are ASKED lines (they have "ask"). How an asked line works, in order:
     a) the tutor asks "ask.prompt" - nothing is written yet;
     b) the learner answers (with "ask.onMiss" as a hint if they are stuck);
     c) only then is "text" written on the board, while the tutor says "say" to confirm it.
   So for an asked line:
     - "text" is the ANSWER, written as a normal board line (e.g. "64 \xD7 2 = 128 chromatids") - never the question, never "ask: ...";
     - "ask.prompt" is the question; it must not contain the answer;
     - "say" is spoken AFTER the learner answered: it confirms and explains the answer ("Yes - each of the 64 doubles, so 128.");
     - "ask.onMiss" is a HINT that points to what is on the board - it must NOT state the answer or the calculation that gives it;
     - "ask.lookFor" says what a good answer contains (the reasoning, not only the result).
   The answer must not appear anywhere BEFORE it is asked: not in an earlier line or its "say", not in the heading,
   and not in a picture step shown before it (check each step's caption and "shows"; move the picture on with the
   asked line's own "picture" field, so it changes only when the answer is written).
   GOOD: earlier line "Parent cell: 64 chromosomes"; asked line text "64 \xD7 2 = 128 chromatids", prompt "Each chromosome copies itself. How many chromatids now?", onMiss "Look at the 64 on the board - what happens to each one?", say "Right - 64 doubled is 128 chromatids."
   BAD: an earlier line "Room = organ" and then asking "If a brick is a cell, what is a room?" (answer already shown).
8. Do not repeat a line in other words. Each line adds something new.
6. Use the standard terms of the syllabus for this grade, define each new term in words before using it, and keep sentences short for this age.
7. Teach ONLY what is in the key facts and worked examples. Do not add facts, numbers or claims from elsewhere.

LESSON SHAPE: 7 to 10 beats.
  b1 "orient": 1-3 lines - what we are learning and why it matters (no question yet).
  then "define" / "show" / "analogy" / "method" beats that build the idea step by step, using a worked example line by line;
  at least one line with "style": "rule" states the key rule or definition;
  1-2 "contrast" beats that each take one misconception: write the wrong idea, test it, show why it fails, write the correct idea;
  an "apply" beat: the learner works a fresh practice item, with asked lines for each step they can do;
  a final "check" beat: one asked line that tests the core idea.
Total lines: 25 to 40. Kinds allowed: ${BEAT_KINDS.join(", ")}. Line styles: "work" (working), "point" (a statement), "rule" (boxed rule).`;
function buildGuidedPrompt(src, pictures) {
  return `You are writing a prepared lesson for an AI voice tutor that teaches one child at a time on a shared chalkboard.
The tutor speaks while the board writes; the child can interrupt at any time.

${METHOD}

${sourceBlock(src, pictures)}

Return ONLY JSON in exactly this shape (the example lines show the style - write your own for this concept):
${SHAPE}`;
}
function buildRepairPrompt(src, pictures, script, problems) {
  return `You wrote this prepared chalkboard lesson. It has problems that must be fixed. Return the WHOLE corrected lesson.

PROBLEMS TO FIX:
${problems.map((p) => `  - ${p}`).join("\n")}

${METHOD}

${sourceBlock(src, pictures)}

THE LESSON TO FIX:
${JSON.stringify(script)}

Return ONLY the corrected JSON, same shape. Keep what is right; change only what the problems require.`;
}
function buildCriticPrompt(src, pictures, script) {
  return `You are an experienced ${src.subject} teacher checking a prepared lesson BEFORE a child sees it. Be strict and specific.
The tutor says each line's "say" while the line is written. Lines with "ask" are hidden until the child answers.

How the lesson runs: the tutor says each line's "say" as the line is written. An ASKED line (it has "ask") works like this:
the tutor asks "ask.prompt" with nothing written; the learner answers; THEN the line's "text" is written and its "say" is spoken to confirm it.
So the "say" and "text" of an asked line coming AFTER the question is correct - do not report that.
The source material is everything listed below (key facts, worked examples, misconceptions, practice items, pictures).

Report an ERROR for any of:
  - a fact, number or calculation that is wrong, or not supported by the source material below;
  - a skipped step: a line that does not follow from the lines above it, or a value used before it is worked out;
  - an answer revealed before its question: in an earlier line or an earlier line's "say", the heading, the ask.prompt itself, the ask.onMiss hint, or a picture step shown before it (check captions and "shows");
  - a "say" that does not match its line, or a misconception stated as if it were true without being corrected;
  - wrong or non-standard terminology for this grade.
Report a WARNING for: wording too hard for the grade, a line with two ideas, a weak hint, or a dull or confusing analogy.
Do not report style preferences.

${sourceBlock(src, pictures)}

THE LESSON:
${JSON.stringify(script)}

Return ONLY JSON: { "issues": [ { "severity": "error" | "warning", "where": "<beat id>/<line id>", "problem": "<what is wrong>", "fix": "<how to fix it>" } ] }
An empty list means the lesson is ready.`;
}
var STYLES = ["work", "point", "rule"];
function normalizeScript(raw, conceptId, fallbackTitle) {
  if (!raw || typeof raw !== "object" || !Array.isArray(raw.beats)) return null;
  const beatIds = /* @__PURE__ */ new Set();
  const beats = raw.beats.map((b, i) => {
    let id = s(b?.id, 24) || `b${i + 1}`;
    if (beatIds.has(id)) id = `b${i + 1}x`;
    beatIds.add(id);
    const kind = BEAT_KINDS.includes(b?.kind) ? b.kind : "show";
    const board = arr(b?.board).flatMap((it) => {
      if (it?.type === "heading" && s(it.text)) return [{ type: "heading", text: s(it.text, 60) }];
      if (it?.type === "picture" && s(it.ref)) return [{ type: "picture", ref: s(it.ref, 120), ...s(it.step) ? { step: s(it.step, 20) } : {} }];
      if ((it?.type === "point" || it?.type === "rule") && s(it.text)) return [{ type: it.type, text: s(it.text, 120) }];
      return [];
    });
    const lineIds = /* @__PURE__ */ new Set();
    const lines = arr(b?.lines).flatMap((l, k) => {
      const text = s(l?.text, 140);
      if (!text) return [];
      let lid = s(l?.id, 24) || `l${k + 1}`;
      if (lineIds.has(lid)) lid = `${lid}_${k + 1}`;
      lineIds.add(lid);
      const line = { id: lid, text, say: s(l?.say, 500), style: STYLES.includes(l?.style) ? l.style : "work" };
      if (l?.ask && s(l.ask.prompt)) line.ask = { prompt: s(l.ask.prompt, 300), lookFor: s(l.ask.lookFor, 300), onMiss: s(l.ask.onMiss, 300) };
      if (l?.picture && s(l.picture.ref)) line.picture = { ref: s(l.picture.ref, 120), ...s(l.picture.step) ? { step: s(l.picture.step, 20) } : {} };
      return [line];
    });
    return { id, kind, say: s(b?.say, 700), board, ...lines.length ? { lines } : {} };
  });
  return { version: 1, conceptId, title: s(raw.title, 80) || fallbackTitle, beats };
}
var isSoft = (e) => /a step is missing/.test(e);
function generatedRules(script) {
  const out = [];
  script.beats.forEach((b, i) => {
    if (!b.lines?.length) out.push(`beat ${i + 1} (${b.id}) has no "lines" - every beat must be written line by line`);
    if (b.ask) out.push(`beat ${i + 1} (${b.id}) has a beat-level "ask" - put questions on lines instead`);
    if (b.board.some((x) => x.type !== "heading" && x.type !== "picture")) out.push(`beat ${i + 1} (${b.id}) writes text in "board" - only a heading and a picture may go there; write text as lines`);
  });
  const asks = script.beats.reduce((n, b) => n + (b.lines?.filter((l) => l.ask).length ?? 0), 0);
  if (asks < 4) out.push(`only ${asks} asked lines - the lesson needs at least 4 lines where the learner answers first`);
  const total = script.beats.reduce((n, b) => n + (b.lines?.length ?? 0), 0);
  if (total > 45) out.push(`${total} lines in total - keep it to 40 or fewer`);
  return out;
}
async function generateGuidedLesson(src, pictures, pictureRefs, model, opts = {}) {
  const maxAttempts = opts.maxAttempts ?? 3;
  const timeoutMs = opts.timeoutMs ?? 18e4;
  let attempts = 0, criticCalls = 0, usedModel;
  let draft = null;
  let problems = [];
  let warnings = [];
  while (attempts < maxAttempts) {
    attempts++;
    const prompt = attempts === 1 || !draft ? buildGuidedPrompt(src, pictures) : buildRepairPrompt(src, pictures, draft, problems);
    let raw;
    try {
      const r = await model({ call: attempts === 1 ? "guided.draft" : "guided.repair", role: "strong", prompt, timeoutMs });
      raw = r.data;
      usedModel = r.model;
    } catch (err) {
      if (isQuotaError(err)) throw new QuotaExhaustedError(String(err?.message || err));
      problems = [`model call failed: ${err?.message || err}`];
      continue;
    }
    const next = normalizeScript(raw, src.conceptId, src.label);
    if (!next) {
      problems = ["the answer was not a lesson in the required JSON shape"];
      continue;
    }
    draft = next;
    const v = validateScript(draft, { expectedConceptId: src.conceptId, pictures: pictureRefs });
    const soft = v.errors.filter(isSoft);
    const hard = [...v.errors.filter((e) => !isSoft(e)), ...generatedRules(draft)];
    warnings = v.warnings;
    const lastDraft = attempts >= maxAttempts;
    problems = lastDraft ? hard : [...hard, ...soft];
    if (lastDraft) warnings = [...warnings, ...soft.map((e) => `check: ${e}`)];
    if (problems.length) continue;
    if (opts.critic === false) break;
    try {
      criticCalls++;
      const c = await model({ call: "guided.critic", role: "review", prompt: buildCriticPrompt(src, pictures, draft), timeoutMs });
      const issues = arr(c.data?.issues).map((x) => ({
        severity: x?.severity === "error" ? "error" : "warning",
        where: s(x?.where, 60),
        problem: s(x?.problem, 400),
        fix: s(x?.fix, 400) || void 0
      })).filter((x) => x.problem);
      const crit = issues.filter((x) => x.severity === "error").map((x) => `[${x.where}] ${x.problem}${x.fix ? ` - fix: ${x.fix}` : ""}`);
      warnings = [...warnings, ...issues.filter((x) => x.severity === "warning").map((x) => `critic [${x.where}]: ${x.problem}`)];
      problems = crit;
      if (!problems.length) break;
    } catch (err) {
      if (isQuotaError(err)) throw new QuotaExhaustedError(String(err?.message || err));
      problems = [`critic could not run: ${err?.message || err}`];
      break;
    }
  }
  if (draft && problems.length === 0) {
    return { script: draft, withheld: false, errors: [], warnings, attempts, criticCalls, model: usedModel };
  }
  return { script: null, withheld: true, quarantined: draft, errors: problems, warnings, attempts, criticCalls, model: usedModel };
}
export {
  QuotaExhaustedError,
  buildCriticPrompt,
  buildGuidedPrompt,
  buildRepairPrompt,
  generateGuidedLesson,
  normalizeScript,
  sourceFromCurriculum
};

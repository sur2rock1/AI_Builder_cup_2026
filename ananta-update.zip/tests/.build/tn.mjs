import { build } from 'esbuild';
await build({ entryPoints: ['src/guided/validate.ts'], bundle: true, platform: 'node', format: 'esm', outfile: 'tests/.build/v.mjs', logLevel: 'warning' });
const { untracedNumbers: u } = await import(process.cwd() + '/tests/.build/v.mjs');
const E = new Set();
const cases = [
 ['rise = 5 − 1 = 4', E, '5,1'], ['gradient = 4 ÷ 0', E, '4,0'], ['gradient = 4 ÷ 0', new Set(['4','0']), ''],
 ['% change = (−0.35 ÷ 2.50) × 100', E, '0.35,2.50,100'], ['= −14.0%', E, ''], ['x1 = -3, y1 = -3', E, ''],
 ['Given: 2x - 3y = 6', E, ''], ['Step 1: Set x = 0', E, ''], ['3x + 7y = 17 (1)', E, ''], ['Zygote (2n) = 46', E, ''],
 ['Soil nitrate = 0.05 mmol/dm3', E, ''], ['4567 = 4000 + 500 + 60 + 7', E, ''], ['200 g ÷ 4 = 50 g per mark', E, '4'],
 ['2 * 5 = 10.', E, '2,5'], ['x + y = 8 (Eq 1)', E, ''], ['12 - 5y = 32', E, '12'], ['Labels = 500 g and 0 g', E, ''],
 ['run = 2 − 2 = 0', E, '2,2'], ['(2, 1)  →  x = 2,  y = 1', E, ''],
];
let bad=0; for (const [l,s,exp] of cases) { const got=u(l,s).join(','); if(got!==exp){bad++; console.log('MISMATCH', JSON.stringify(l), 'got', got, 'want', exp);} }
console.log(bad? bad+' mismatches':'all cases ok');

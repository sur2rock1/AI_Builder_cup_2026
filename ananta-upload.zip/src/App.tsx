import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  BlackboardState,
  BlackboardTab,
  TutorState,
  TranscriptEntry,
  ConnectionStatus,
  DynamicLessonData,
  ConceptNode,
  TeachingPlanUI,
  ReasoningLogEntryUI,
  DiagnosisUpdateUI,
  EvidenceResultUI,
  PlanUpdateUI,
} from './types';
import { AnimatedTutorCharacter } from './components/AnimatedTutorCharacter';
import { DynamicBlackboard } from './components/DynamicBlackboard';
import { TopicGradeSelector } from './components/TopicGradeSelector';
import { BottomBar } from './components/BottomBar';
import { AudioManager } from './utils/audio';
import { createDynamicLesson } from './utils/lessonGenerator';
import { liveWebSocketUrl } from './utils/liveWs';
import { authFetch } from './firebase/auth';
import { Sparkles, RefreshCw } from 'lucide-react';
import { LearnerProfilePanel } from './components/LearnerProfilePanel';
import { TutorReasoningPanel } from './components/TutorReasoningPanel';
import { AdminLibrary } from './components/AdminLibrary';
import {
  LearnerProfileUI, AdaptiveSessionUI, AssessmentResultUI,
  CurriculumConceptUI,
} from './types';
import { LoginScreen, StudentProfile } from './components/LoginScreen';
import { Onboarding } from './components/Onboarding';
import { SubjectSelector } from './components/SubjectSelector';
import { ParentPortal } from './components/ParentPortal';
import {
  TeachingCanvas, resolvePart, FigurePart, FigureSpec,
  StudentThinking, LiveAssessment, BoardNote,
} from './components/TeachingCanvas';

import type { LearnerSnapshot } from './adaptive/liveObserver';
import { ImmersiveStage, PresenterMedia } from './components/ImmersiveStage';
import { PanelMode } from './components/ScenePanel';
import { getScene } from './scenes/genericScenes';
import type { StepState } from './components/BoardVisualView';
import type { BoardVisual, BoardVisual3D } from './visual/types';
import { matchRevealTarget } from './visual/tutorBrief';
import { normalizeQuiz, isQuizShape } from './quality/quizTools';
import type { QuizReasoning } from './types';

// Which teaching surface to render.
//   'immersive' — presenter on a stage beside a real whiteboard (current)
//   'canvas'    — flat light teaching canvas
//   'legacy'    — the original six-tab blackboard
// Kept as a flag so there is always a working fallback close to the deadline.
type BoardSurface = 'immersive' | 'canvas' | 'legacy';
const BOARD_SURFACE: BoardSurface = 'immersive';

// Pre-generated presenter media. Drop files into /public/presenter/ and list
// them here — nothing is generated at runtime, so there is no added latency
// and no third-party avatar service sitting in the live path.
// Until these exist the stage renders a lit silhouette instead.
const PRESENTER: PresenterMedia = {
  // Produced by `npm run gen:assets`. Used only if the file exists.
  still: '/presenter/stage.jpg',
  // clips: {
  //   idle:        '/presenter/idle.mp4',
  //   talking:     '/presenter/talking.mp4',
  //   thinking:    '/presenter/thinking.mp4',
  //   pointing:    '/presenter/pointing.mp4',
  //   encouraging: '/presenter/encouraging.mp4',
  // },
};

export const App: React.FC = () => {
  // ─── Navigation / screen state ───────────────────────────────
  type AppScreen = 'login' | 'onboarding' | 'subject-select' | 'tutor' | 'parent-portal' | 'admin';
  const [screen, setScreen] = useState<AppScreen>('login');
  const [loggedInStudent, setLoggedInStudent] = useState<StudentProfile | null>(null);

  // Topic and Grade State
  const [topic, setTopic] = useState('');
  const [grade, setGrade] = useState('Secondary 2 (Grade 8)');

  // ─── Adaptive learning state ──────────────────────────────────
  const [learnerProfile, setLearnerProfile] = useState<LearnerProfileUI | null>(null);
  const [adaptiveSession, setAdaptiveSession] = useState<AdaptiveSessionUI | null>(null);
  const [currentConcept, setCurrentConcept] = useState<CurriculumConceptUI | null>(null);
  const [lastAssessment, setLastAssessment] = useState<AssessmentResultUI | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [profilePanelOpen, setProfilePanelOpen] = useState(false);
  // Curriculum concept behind the current lesson, so lesson/diagram requests
  // can hit the per-concept pregenerated cache (data/pregenerated/<conceptId>.json)
  // rather than a label slug that two courses might share (docs/CURRICULUM.md §8).
  const lessonConceptRef = useRef<{ id: string; label: string } | null>(null);
  const conceptIdFor = (label: string) =>
    lessonConceptRef.current && lessonConceptRef.current.label === label ? lessonConceptRef.current.id : undefined;

  // ─── Live teaching state (new canvas) ────────────────────────
  const [figure, setFigure] = useState<FigureSpec>({ a: 4, b: 3, unknownSide: null });
  const [revealed, setRevealed] = useState<FigurePart[]>([]);
  // Pre-generated real-world photo for this topic (base64 data URI from pregen cache).
  // Shown in the real-world panel when the scene photo is not available or not calibrated.
  const [pregenPhoto, setPregenPhoto] = useState<string | null>(null);
  const [pregenPhotoCaption, setPregenPhotoCaption] = useState<string | null>(null);
  const [focusPart, setFocusPart] = useState<FigurePart | null>(null);
  // Lesson opens on a real situation, then fades to the bare shape (concreteness fading).
  const [panelMode, setPanelMode] = useState<PanelMode>('real');
  // True while the server is checking an answer. Shown to the child so a short
  // pause reads as "he's thinking about what I said", not as a hang.
  const [tutorThinking, setTutorThinking] = useState(false);
  const thinkingTimerRef = useRef<number | null>(null);
  const setThinking = useCallback((on: boolean) => {
    if (thinkingTimerRef.current) { window.clearTimeout(thinkingTimerRef.current); thinkingTimerRef.current = null; }
    setTutorThinking(on);
    // Never let the indicator stick if a message is lost.
    if (on) thinkingTimerRef.current = window.setTimeout(() => setTutorThinking(false), 8000);
  }, []);
  const [sceneId, setSceneId] = useState<string>('ladder');
  const [studentThinking, setStudentThinking] = useState<StudentThinking | null>(null);
  const [liveAssessment, setLiveAssessment] = useState<LiveAssessment | null>(null);
  const [boardNote, setBoardNote] = useState<BoardNote | null>(null);
  const [liveMastery, setLiveMastery] = useState<number>(0);
  const [liveMisconceptions, setLiveMisconceptions] = useState<Array<{ id: string; text: string; status: string }>>([]);
  // Live learner picture from the server's observer (updated after every exchange).
  const [learnerSnap, setLearnerSnap] = useState<LearnerSnapshot | null>(null);

  // T23 — Tutor's-reasoning panel state.
  const [teachingPlan, setTeachingPlan] = useState<TeachingPlanUI | null>(null);
  const [reasoningLog, setReasoningLog] = useState<ReasoningLogEntryUI[]>([]);
  const [reasoningPanelOpen, setReasoningPanelOpen] = useState(false);

  const revealPart = useCallback((part: FigurePart | null) => {
    if (!part) return;
    setRevealed(prev => (prev.includes(part) ? prev : [...prev, part]));
    setFocusPart(part);
    // The spotlight is a moment, not a state. It fades so the board settles.
    window.setTimeout(() => setFocusPart(curr => (curr === part ? null : curr)), 6000);
  }, []);

  // ─── Board pictures (docs/BOARD_VISUALS.md) ──────────────────
  // How far each picture has been built. The tutor moves these with reveal_part;
  // the learner can also step through with the arrows on the board.
  const [visualStep, setVisualStep] = useState<StepState>(0);
  const [visual3dStep, setVisual3dStep] = useState<StepState>(0);
  // Bricks the tutor is pointing at right now (reveal_part / highlight_concept of a part).
  const [visualSpotlight, setVisualSpotlight] = useState<string[]>([]);
  const spotlightTimerRef = useRef<number | null>(null);
  // Tool calls arrive in a callback that does not re-render with the lesson, so the
  // pictures currently on the board are mirrored into a ref for it to read.
  const boardVisualsRef = useRef<{ visual: BoardVisual | null; visual3d: BoardVisual3D | null; legacy3d: boolean }>({ visual: null, visual3d: null, legacy3d: false });

  const spotlight = useCallback((ids: string[]) => {
    if (spotlightTimerRef.current) window.clearTimeout(spotlightTimerRef.current);
    setVisualSpotlight(ids);
    // Like revealPart's focus: a moment, not a state.
    if (ids.length) spotlightTimerRef.current = window.setTimeout(() => setVisualSpotlight([]), 6000);
  }, []);

  /** Point the board at whatever the tutor just named. Returns false when nothing matched. */
  const showOnBoard = useCallback((phrase: string, opts: { moveStep: boolean }): boolean => {
    const { visual, visual3d } = boardVisualsRef.current;
    const target = matchRevealTarget([{ key: 'main', visual }, { key: '3d', visual: visual3d }], phrase);
    if (!target) return false;
    const isStep = target.elementIds.length === 0;
    const advance = (prev: StepState): StepState => {
      const idx = target.stepIndex;
      if (idx === null) return prev;
      if (isStep && opts.moveStep) return idx;                 // a step name: go there, forward or back
      if (prev === 'all') return prev;                          // everything is already on the board
      return typeof prev === 'number' && prev < idx ? idx : prev; // a named part not drawn yet: bring its step in
    };
    if (target.key === '3d') {
      setPanelMode('3d');
      setVisual3dStep(advance);
    } else {
      setPanelMode('shape');
      setVisualStep(advance);
    }
    spotlight(target.elementIds);
    return true;
  }, [spotlight]);

  // ─── Blackboard State
  const [blackboard, setBlackboard] = useState<BlackboardState>({
    activeTab: '2d',
    lessonData: null,
    isLoading: false,
    isGeneratingPhoto: false,
    highlightedNodeId: null,
    interactiveValues: {},
    selectedQuizOption: null,
    showQuizResult: false,
    customLiveNotes: [],
  });

  // Keep the tool-call handler's view of the board pictures current.
  useEffect(() => {
    const lesson = blackboard.lessonData;
    boardVisualsRef.current = {
      visual: lesson?.visual ?? null,
      visual3d: lesson?.visual3d ?? null,
      legacy3d: !!lesson?.scene3d && !lesson?.visual,
    };
  }, [blackboard.lessonData]);

  // Animated Tutor State
  const [tutorState, setTutorState] = useState<TutorState>({
    isSpeaking: false,
    mouthOpenness: 0,
    isBlinking: false,
    isNodding: false,
    eyebrowsRaised: false,
    name: 'Dr. Marcus Vance',
    title: 'Senior AI Educator',
  });

  // Voice & Transcripts State
  const [outputTranscript, setOutputTranscript] = useState<TranscriptEntry | null>({
    id: 'welcome-0',
    text: `Hello! I am Dr. Marcus Vance, your real-time AI tutor. What topic or concept would you like to explore today? Type any topic on the fly or click "Start Voice Lesson" to ask me directly!`,
    timestamp: Date.now(),
  });
  const [inputTranscript, setInputTranscript] = useState<TranscriptEntry | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [micLevel, setMicLevel] = useState(0);

  // Audio & WebSocket Refs
  const audioManagerRef = useRef<AudioManager | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Load / Generate Lesson Data on the Fly
  const loadLesson = useCallback(async (targetTopic: string, targetGrade: string, requestedTab?: BlackboardTab) => {
    if (!targetTopic.trim()) return;

    // Reset scene to neutral for non-Pythagorean topics so the wrong photo doesn't show
    if (!/pythag/i.test(targetTopic)) setSceneId('');

    setBlackboard((prev) => ({
      ...prev,
      isLoading: true,
      selectedQuizOption: null,
      showQuizResult: false,
      customLiveNotes: [],
    }));

    try {
      // 1. Attempt fresh AI generation from server
      const res = await fetch('/api/generate-lesson', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: targetTopic, grade: targetGrade, conceptId: conceptIdFor(targetTopic) }),
      });

      const json = await res.json();

      // Store pre-generated real-world photo when the server includes one
      setPregenPhoto(json?.photoUrl ?? null);
      setPregenPhotoCaption(json?.photoCaption ?? null);

      let finalData: DynamicLessonData;
      if (json && json.data) {
        finalData = json.data;
        // Restore calculateOutcome: functions are dropped by JSON serialisation.
        // If the server merged a static explorer into the response, re-attach the
        // live function from createDynamicLesson so the explorer slider works.
        if (finalData.explorer && !finalData.explorer.calculateOutcome) {
          const localLesson = createDynamicLesson(targetTopic, targetGrade);
          if (localLesson.explorer?.calculateOutcome) {
            finalData.explorer.calculateOutcome = localLesson.explorer.calculateOutcome;
          }
        }
      } else {
        // Fallback to intelligent local generator
        finalData = createDynamicLesson(targetTopic, targetGrade);
      }

      // A quiz must never be answerable by position: legacy/stored quizzes are put in seeded order at runtime
      // (idempotent for anything already shuffled at generation), and an unusable quiz is dropped, not shown.
      if (finalData.quiz) {
        const q = normalizeQuiz(finalData.quiz, targetTopic);
        finalData = { ...finalData, quiz: (q ?? undefined) as any };
      }

      // Template content the offline generator invents (a generic 3D scene, "Key Point" photo pins) is not
      // shown: only a verified photo / a board picture the gates passed. Pythagoras keeps its hand-built scene.
      if (!/pythag/i.test(targetTopic)) {
        finalData = { ...finalData, scene3d: undefined, photoVisual: finalData.photoVisual?.imageUrl ? finalData.photoVisual : undefined };
      }

      // Initialize interactive variables
      const initialVals: Record<string, number> = {};
      if (finalData.explorer?.variables) {
        finalData.explorer.variables.forEach((v) => {
          initialVals[v.id] = v.defaultValue;
        });
      }

      setBlackboard({
        activeTab: requestedTab || '2d',
        lessonData: finalData,
        isLoading: false,
        isGeneratingPhoto: false,
        highlightedNodeId: null,
        interactiveValues: initialVals,
        selectedQuizOption: null,
        showQuizResult: false,
        customLiveNotes: [],
      });

      // Pre-populate Pythagorean figure parts for overview before voice session.
      // For non-Pythagorean topics the board picture handles visualisation;
      // revealed is left empty so no unrelated triangle parts leak into the UI.
      if (/pythag/i.test(targetTopic)) {
        setRevealed(['triangle', 'right-angle', 'leg-a', 'leg-b', 'hypotenuse', 'formula']);
      } else {
        setRevealed([]);
      }
      // A new lesson's picture starts at its first step: one idea at a time.
      setVisualStep(0);
      setVisual3dStep(0);
      setVisualSpotlight([]);

      // Say only what this lesson actually has (a 3D model exists only when it helps).
      const offer = [
        finalData.visual ? 'a picture we’ll build step by step' : 'a diagram',
        finalData.visual3d ? 'a 3D model' : null,
        'a real-world photo',
        'chalkboard notes',
        'a question to try',
      ].filter(Boolean) as string[];
      setOutputTranscript({
        id: `topic-${Date.now()}`,
        text: `Ready for "${finalData.topic}" (${finalData.grade}): ${offer.slice(0, -1).join(', ')} and ${offer[offer.length - 1]}.`,
        timestamp: Date.now(),
      });
    } catch (err) {
      console.error('[App] Error fetching lesson, using local generator:', err);
      const fallbackData = createDynamicLesson(targetTopic, targetGrade);
      const initialVals: Record<string, number> = {};
      if (fallbackData.explorer?.variables) {
        fallbackData.explorer.variables.forEach((v) => {
          initialVals[v.id] = v.defaultValue;
        });
      }

      setBlackboard({
        activeTab: requestedTab || '2d',
        lessonData: fallbackData,
        isLoading: false,
        isGeneratingPhoto: false,
        highlightedNodeId: null,
        interactiveValues: initialVals,
        selectedQuizOption: null,
        showQuizResult: false,
        customLiveNotes: [],
      });
    }
  }, []);

  // Handle Changing / Launching Topic and Grade on the Fly
  const handleApplyTopicAndGrade = (newTopic: string, newGrade?: string) => {
    const selectedGrade = newGrade || grade;
    setTopic(newTopic);
    if (newGrade) setGrade(newGrade);

    // If currently connected in voice, disconnect to start fresh with new topic
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    if (audioManagerRef.current) {
      audioManagerRef.current.stop();
      audioManagerRef.current = null;
    }
    setConnectionStatus('disconnected');

    loadLesson(newTopic, selectedGrade);
  };

  // Generate Photo Visual on the Fly using AI
  const handleGeneratePhoto = async (customPrompt?: string) => {
    const activeTopic = topic || blackboard.lessonData?.topic || 'Science';
    setBlackboard((prev) => ({ ...prev, isGeneratingPhoto: true, photoNotice: null }));

    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: activeTopic,
          prompt: customPrompt,
          conceptId: conceptIdFor(activeTopic),
        }),
      });

      const data = await res.json();
      if (data && data.imageUrl) {
        setBlackboard((prev) => {
          if (!prev.lessonData) return prev;
          return {
            ...prev,
            activeTab: 'photo',
            isGeneratingPhoto: false,
            lessonData: {
              ...prev.lessonData,
              photoVisual: {
                imageUrl: data.imageUrl,
                caption: data.caption || activeTopic,
                promptUsed: data.promptUsed || customPrompt || activeTopic,
                aiGenerated: true,
                annotations: [],
              },
            },
          };
        });

        setOutputTranscript({
          id: `photo-${Date.now()}`,
          text: `I made an illustration for "${activeTopic}" — it is AI-generated, so tell me if anything in it looks off. Take a look on the board.`,
          timestamp: Date.now(),
        });
      } else {
        setBlackboard((prev) => ({ ...prev, isGeneratingPhoto: false, activeTab: 'photo', photoNotice: data?.error || 'No verified picture is available for this yet.' }));
      }
    } catch (err) {
      console.error('[App] Error generating image:', err);
      setBlackboard((prev) => ({ ...prev, isGeneratingPhoto: false, activeTab: 'photo', photoNotice: 'Picture generation failed — please try again.' }));
    }
  };

  // Lipsync & Audio Visualizer Animation Loop
  useEffect(() => {
    const updateLipsync = () => {
      if (audioManagerRef.current) {
        const outLevel = typeof audioManagerRef.current.getOutputLevel === 'function'
          ? audioManagerRef.current.getOutputLevel()
          : (typeof audioManagerRef.current.getOutputRMS === 'function' ? audioManagerRef.current.getOutputRMS() : 0);
        const clampedLevel = Math.min(1, outLevel * 2.8);

        setTutorState((prev) => ({
          ...prev,
          mouthOpenness: clampedLevel,
          isSpeaking: clampedLevel > 0.08,
          eyebrowsRaised: clampedLevel > 0.4,
        }));
      }
      animFrameRef.current = requestAnimationFrame(updateLipsync);
    };

    animFrameRef.current = requestAnimationFrame(updateLipsync);
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  // Newest picture request wins: a slow response for an older request must never replace what the
  // tutor is showing now (the live-drawn picture can take 20+ s).
  const boardRequestSeq = useRef(0);

  /** Send a front-end event to the server log (logs/server-*.log) so blank-board reports can be diagnosed. */
  const clientLog = useCallback((tag: string, msg: string) => {
    try {
      fetch('/api/client-log', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ tag, msg }), keepalive: true }).catch(() => {});
    } catch { /* logging must never break the UI */ }
  }, []);
  useEffect(() => {
    const onErr = (e: ErrorEvent) => clientLog('window.error', `${e.message} @ ${e.filename}:${e.lineno}`);
    const onRej = (e: PromiseRejectionEvent) => clientLog('unhandledrejection', String((e.reason && (e.reason.stack || e.reason.message)) || e.reason));
    window.addEventListener('error', onErr);
    window.addEventListener('unhandledrejection', onRej);
    return () => { window.removeEventListener('error', onErr); window.removeEventListener('unhandledrejection', onRej); };
  }, [clientLog]);

  // Handle Tool Calls from Gemini Live Voice Model
  const handleToolCall = useCallback(
    (name: string, args: Record<string, any>, serverResult?: Record<string, any>) => {
      console.log(`[App] Handling Gemini Live tool call: ${name}`, args, serverResult);

      /** Put a picture from /api/update-diagram on the board, starting at its first step.
       * On failure the board keeps the picture it has — never a generic stand-in. */
      const applyBoardVisual = (json: any, from: string): boolean => {
        if (json?.success && json.visual) {
          const v = json.visual as BoardVisual;
          const current = boardVisualsRef.current.visual;
          // Same picture asked for again (e.g. the tutor re-requests the lesson's main picture mid-explanation):
          // keep the build-up where it is instead of wiping it back to step 0.
          const same = !!current && JSON.stringify(current) === JSON.stringify(v);
          if (!same) {
            setBlackboard((prev) => (prev.lessonData
              ? { ...prev, activeTab: '2d', highlightedNodeId: null, lessonData: { ...prev.lessonData, visual: v } }
              : prev));
            setVisualStep(0);
            setVisualSpotlight([]);
            // The ref is otherwise refreshed by an effect after render; a reveal_part arriving in the same
            // moment must already see the new picture's step names.
            boardVisualsRef.current = { ...boardVisualsRef.current, visual: v };
          }
          setPanelMode('shape');
          console.log(`[${from}] board picture "${v.title}" (${json.key || 'new'}, ${json.source || 'unknown'})${same ? ' — same as current, progress kept' : ''}`);
          clientLog('board.apply', `${from} "${v.title}" key=${json.key || 'new'} steps=${v.steps?.length} elements=${v.elements?.length} ${same ? 'SAME(kept step)' : 'replaced, step 0'}`);
          return true;
        }
        console.warn(`[${from}] no picture — keeping the current one:`, json?.error || json);
        clientLog('board.keep', `${from} no picture: ${String(json?.error || 'unknown').slice(0, 200)}`);
        return false;
      };

      switch (name) {
        // ─── New teaching canvas tools ────────────────────────
        case 'reveal_part': {
          const list: string[] = Array.isArray(args.parts) && args.parts.length ? args.parts : args.part ? [args.part] : [];
          const { visual, visual3d } = boardVisualsRef.current;
          if ((visual || visual3d) && !/pythag/i.test(topic || '')) {
            // A generated board picture: each name is a step (or a part) of it. Several
            // names in one call are shown a beat apart, keeping pace with the voice.
            list.forEach((p, i) => {
              window.setTimeout(() => {
                if (!showOnBoard(String(p), { moveStep: true })) { console.info(`[reveal_part] "${p}" matched nothing on the board`); clientLog('board.reveal-miss', `"${String(p).slice(0, 60)}" matched nothing on "${boardVisualsRef.current.visual?.title}"`); }
              }, i * 1800);
            });
            break;
          }
          setPanelMode(prev => (prev === '3d' ? 'shape' : prev));
          // One call, several parts: reveal them in order, a beat apart, so the
          // board keeps pace with the explanation without a tool call per word.
          list.forEach((p, i) => {
            const part = resolvePart(String(p)) || (p as FigurePart);
            window.setTimeout(() => revealPart(part), i * 1800);
          });
          break;
        }

        case 'set_figure': {
          if (args.scene && getScene(String(args.scene)) !== null) {
            setSceneId(String(args.scene));
            setPanelMode('real');
          } else {
            setPanelMode(prev => (prev === '3d' ? 'shape' : prev));
          }
          const a = Number(args.a);
          const b = Number(args.b);
          if (Number.isFinite(a) && Number.isFinite(b) && a > 0 && b > 0) {
            setFigure({
              a, b,
              unitLabel: args.unitLabel ? String(args.unitLabel) : undefined,
              unknownSide: ['a', 'b', 'c'].includes(args.unknownSide) ? args.unknownSide : null,
            });
            // A new figure is a new question — clear the previous reasoning.
            setStudentThinking(null);
            // Only add triangle reveal for Pythagorean topics
            if (/pythag/i.test(topic || '')) {
              setRevealed(prev => (prev.includes('triangle') ? prev : [...prev, 'triangle']));
            }
          }
          break;
        }

        case 'show_student_thinking': {
          const verdict = ['sound', 'checking', 'breaks_down'].includes(args.verdict)
            ? args.verdict : 'checking';
          setStudentThinking({
            method: String(args.method || ''),
            faultyStep: args.faultyStep ? String(args.faultyStep) : undefined,
            verdict,
          });
          break;
        }

        case 'assess_child_reasoning': {
          if (serverResult && serverResult.result === 'checking') {
            const said = String(args.childReasoning || args.childAnswer || '');
            if (said) setStudentThinking({ method: said, verdict: 'checking' });
          }
          if (serverResult && serverResult.result === 'assessed') {
            setLiveAssessment(serverResult as LiveAssessment);
            if (serverResult.mastery?.after !== undefined) setLiveMastery(serverResult.mastery.after);
            if (Array.isArray(serverResult.misconceptions)) setLiveMisconceptions(serverResult.misconceptions);
            // Reflect the verdict onto the child's method already on the board.
            setStudentThinking(prev => {
              const summary = serverResult.reasoningSummary || prev?.method || '';
              if (!summary) return prev;
              const verdict: StudentThinking['verdict'] =
                serverResult.classification === 'clear_reasoning' ? 'sound'
                : serverResult.shouldProbe ? 'checking'
                : 'breaks_down';
              return { method: summary, faultyStep: serverResult.faultyStep || undefined, verdict };
            });
          }
          break;
        }

        case 'record_confusion_signal': {
          // Acknowledged on the server; nothing to draw. Never surfaced as a failure.
          break;
        }

        case 'update_chalkboard_notes': {
          const bulletPoints = Array.isArray(args.bulletPoints) ? args.bulletPoints : [];
          const coreRule = args.coreRuleOrFormula || undefined;
          const title = args.title || undefined;

          setBoardNote({ title, lines: bulletPoints.map(String), formula: coreRule });
          // Writing on the board: switch to the chalkboard, on a fresh page.
          setPanelMode('chalk');
          setBlackboard(prev => ({ ...prev, customLiveNotes: [] }));
          if (coreRule) revealPart('formula');

          setBlackboard((prev) => {
            if (!prev.lessonData) return prev;
            return {
              ...prev,
              activeTab: 'chalkboard',
              lessonData: {
                ...prev.lessonData,
                chalkNotes: {
                  ...prev.lessonData.chalkNotes,
                  title: title || prev.lessonData.chalkNotes.title,
                  bulletPoints:
                    bulletPoints.length > 0 ? bulletPoints : prev.lessonData.chalkNotes.bulletPoints,
                  coreRuleOrFormula: coreRule || prev.lessonData.chalkNotes.coreRuleOrFormula,
                },
              },
            };
          });
          break;
        }

        case 'write_live_note': {
          const note = args.note;
          if (note) {
            setBlackboard((prev) => ({
              ...prev,
              activeTab: 'chalkboard',
              customLiveNotes: [...prev.customLiveNotes, String(note)],
            }));
            setPanelMode('chalk');
          }
          break;
        }

        case 'switch_board_view': {
          let tab = args.tab as BlackboardTab;
          if ((tab as any) === 'diagram') tab = '2d';
          if (['2d', '3d', 'photo', 'chalkboard', 'explorer', 'quiz'].includes(tab)) {
            setBlackboard((prev) => ({ ...prev, activeTab: tab }));
          }
          // Six legacy tabs collapse onto three views: real world, shape, 3D.
          // A 3D view exists only when it helps this idea; otherwise the Shape view stands in.
          const { visual, visual3d, legacy3d } = boardVisualsRef.current;
          const has3D = !!visual3d || legacy3d;
          setPanelMode(tab === '3d' ? (has3D ? '3d' : 'shape') : tab === 'photo' ? 'real' : tab === 'chalkboard' ? 'chalk' : 'shape');
          // An older lesson with no board picture yet: ask for its teaching picture
          // (drawn once, then stored as the lesson's main picture). A lesson that has
          // one keeps it — switching views never replaces the picture being built.
          if (tab === '2d' && !visual && !/pythag/i.test(topic || '')) {
            const autoTopic = topic;
            const seqAuto = ++boardRequestSeq.current;
            (async () => {
              try {
                const res = await fetch('/api/update-diagram', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ topic: autoTopic, grade, focus: autoTopic, conceptId: conceptIdFor(autoTopic) }),
                });
                const jsonAuto = await res.json();
                if (seqAuto === boardRequestSeq.current) applyBoardVisual(jsonAuto, 'switch_board_view');
              } catch (err) {
                console.warn('[switch_board_view] picture request failed:', err);
              }
            })();
          }
          break;
        }

        case 'generate_photo_visual': {
          setPanelMode('real');
          const prompt = args.prompt;
          handleGeneratePhoto(prompt);
          break;
        }

        case 'set_topic': {
          const newTopic = args.topic;
          const newGrade = args.grade;
          if (newTopic) {
            setTopic(newTopic);
            if (newGrade) setGrade(newGrade);
            loadLesson(newTopic, newGrade || grade);
          }
          break;
        }

        case 'highlight_concept': {
          const target = String(args.nodeIdOrName || '').toLowerCase();
          // On a board picture: spotlight the named part (bringing it in if not drawn yet).
          if (boardVisualsRef.current.visual && !/pythag/i.test(topic || '') && showOnBoard(target, { moveStep: false })) break;
          revealPart(resolvePart(target));
          setBlackboard((prev) => {
            const matched = prev.lessonData?.diagram.nodes.find(
              (n) => n.id.toLowerCase().includes(target) || n.label.toLowerCase().includes(target)
            );
            return {
              ...prev,
              activeTab: '2d',
              highlightedNodeId: matched ? matched.id : null,
            };
          });
          break;
        }

        case 'pose_quiz': {
          const question = args.question;
          const options = args.options;
          const correctIndex = Number(args.correctIndex) || 0;
          const explanation = args.explanation || 'Review the core concept breakdown.';

          // Put the question on the chalkboard so the child can see what to solve.
          // (Before, this only updated the old blackboard's quiz tab, which the
          // immersive stage never shows — the board looked frozen.) The answer
          // and explanation are NOT written: the child works it out.
          if (question) {
            const opts: string[] = Array.isArray(options) ? options.map(String).filter(Boolean) : [];
            setBoardNote({
              title: 'Your turn',
              lines: [`Question: ${question}`, ...opts.map((o, i) => `${'ABCDEFGH'[i] || i + 1})  ${o}`)],
            });
            setBlackboard(prev => ({ ...prev, customLiveNotes: [] }));
            setPanelMode('chalk');
          }

          if (question && Array.isArray(options) && isQuizShape({ question, options, correctIndex, explanation })) {
            setBlackboard((prev) => {
              if (!prev.lessonData) return prev;
              return {
                ...prev,
                activeTab: 'quiz',
                selectedQuizOption: null,
                showQuizResult: false,
                lessonData: {
                  ...prev.lessonData,
                  quiz: {
                    question,
                    options,
                    correctIndex,
                    explanation,
                  },
                },
              };
            });
          }
          break;
        }

        case 'update_diagram': {
          const focus = String(args.focus || '');
          if (/pythag/i.test(topic || '')) revealPart(resolvePart(focus));
          const currentTopic = topic;
          const currentGrade = grade;
          setBlackboard((prev) => ({ ...prev, activeTab: '2d' }));
          // The prepared picture (a contrast case, the application picture) arrives
          // instantly; a new one takes a few seconds. The server tells the tutor its
          // step names in the tool response, so the tutor can build it up.
          const seq = ++boardRequestSeq.current;
          const t0 = Date.now();
          clientLog('board.request', `update_diagram #${seq} focus="${focus.slice(0, 80)}"`);
          (async () => {
            try {
              const res = await fetch('/api/update-diagram', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ topic: currentTopic, grade: currentGrade, focus, conceptId: conceptIdFor(currentTopic) }),
              });
              const json = await res.json();
              if (seq !== boardRequestSeq.current) {
                clientLog('board.stale', `update_diagram #${seq} finished after ${Date.now() - t0}ms but #${boardRequestSeq.current} is newer — discarded`);
                return;
              }
              applyBoardVisual(json, 'update_diagram');
            } catch (err) {
              console.warn('[update_diagram] picture request failed — keeping the current one:', err);
              clientLog('board.error', `update_diagram #${seq} failed: ${String((err as any)?.message || err)}`);
            }
          })();
          break;
        }

        default:
          console.warn(`[App] Unhandled tool call: ${name}`);
      }
    },
    [grade, topic, loadLesson, revealPart, showOnBoard, clientLog]
  );

  // ─── Adaptive session handlers ─────────────────────────────
  const handleStartSession = async (studentId: string, name: string, grade: string, subjectId: string) => {
    try {
      const res = await authFetch('/api/session/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId, name, grade, subjectId }),
      });
      const json = await res.json();
      if (json.sessionId) {
        setSessionId(json.sessionId);
        setLearnerProfile(json.learner);
        setAdaptiveSession(json.session || {
          sessionId: json.sessionId, studentId, subjectId,
          currentConceptId: json.currentConcept?.id,
          currentStrategy: 'direct_explanation',
          sessionStarted: Date.now(), interactionCount: 0, recentAttempts: [],
        });
        setCurrentConcept(json.currentConcept || null);
        lessonConceptRef.current = json.currentConcept ? { id: json.currentConcept.id, label: json.currentConcept.label } : null;
        // T17/T18/T23 — the deterministic Teaching Plan compiled for this
        // session, feeding the Tutor's-reasoning panel from the moment the
        // lesson opens (before any live exchange has happened yet).
        setTeachingPlan(json.plan || null);
        setReasoningLog([]);
        // Panel stays closed — user can open it via the Profile button in the top nav
        // Load lesson for this concept
        if (json.currentConcept) loadLesson(json.currentConcept.label, grade);
        setOutputTranscript({
          id: `session-${Date.now()}`,
          text: `Welcome back, ${name}! Today we are working on "${json.currentConcept?.label}". I have tailored this session based on your learning history.`,
          timestamp: Date.now(),
        });
      }
    } catch (err) { console.error('[Session] Failed to start:', err); }
  };

  const handleAdaptiveQuizAnswer = async (selectedIdx: number, reasoning?: QuizReasoning) => {
    // First update UI normally
    setBlackboard(prev => ({ ...prev, selectedQuizOption: selectedIdx, showQuizResult: true }));

    if (!sessionId || !blackboard.lessonData) return;
    const quiz = blackboard.lessonData.quiz;
    if (!quiz) return;

    try {
      const res = await authFetch(`/api/session/${sessionId}/assess`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questionSummary: quiz.question,
          studentAnswer: quiz.options[selectedIdx],
          correctAnswer: quiz.options[quiz.correctIndex],
          selectedOptionIndex: selectedIdx,
          correctOptionIndex: quiz.correctIndex,
          itemId: quiz.itemId,
          reasoning,
        }),
      });
      const json = await res.json();
      if (json.assessment) {
        setLastAssessment(json.assessment);
        if (json.learner) setLearnerProfile(json.learner);
        if (json.session) setAdaptiveSession(json.session);
        if (json.advancedToConcept) {
          setCurrentConcept(json.advancedToConcept);
          setOutputTranscript({
            id: `advance-${Date.now()}`,
            text: `You have this one. Let's move on to "${json.advancedToConcept.label}".`,
            timestamp: Date.now(),
          });
        } else if (json.assessment.recommendedAction === 'switch_strategy') {
          setOutputTranscript({
            id: `switch-${Date.now()}`,
            text: `Let's look at this another way — I'll show it with ${json.nextStrategy?.replace(/_/g, ' ')}.`,
            timestamp: Date.now(),
          });
        }
      }
    } catch (err) { console.error('[Assessment] Failed:', err); }
  };

  // Start or Stop Live Voice Lesson
  const toggleVoiceLesson = async () => {
    if (connectionStatus === 'connected' || connectionStatus === 'connecting') {
      // Stop session
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      if (audioManagerRef.current) {
        audioManagerRef.current.stop();
        audioManagerRef.current = null;
      }
      setConnectionStatus('disconnected');
      setMicLevel(0);
      setTutorState((prev) => ({ ...prev, isSpeaking: false, mouthOpenness: 0 }));
      return;
    }

    // Start session
    try {
      setConnectionStatus('connecting');

      // 1. Initialize Audio Manager
      const audioMgr = new AudioManager({
        onAudioInputChunk: (base64PCM) => {
          if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({ type: 'audio_in', data: base64PCM }));
          }
        },
        onInputLevel: (level) => {
          setMicLevel(level);
        },
      });

      await audioMgr.start();
      audioManagerRef.current = audioMgr;

      // 2. Connect WebSocket to Gemini Live with topic and grade query params
      const activeTopic = topic || 'any topic the student asks for on the fly';
      const wsUrl = liveWebSocketUrl(
        activeTopic,
        grade,
        adaptiveSession?.subjectId,
        adaptiveSession?.currentConceptId,
        adaptiveSession?.sessionId,
      );

      const socket = new WebSocket(wsUrl);
      wsRef.current = socket;

      socket.onopen = () => {
        console.log('[WebSocket] Connected to Gemini Live', wsUrl);
      };

      socket.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'audio_out' && msg.data) {
            audioMgr.queueAudioChunk(msg.data);
          } else if (msg.type === 'output_transcript' && msg.text) {
            setOutputTranscript({
              id: `out-${Date.now()}`,
              text: msg.text,
              timestamp: Date.now(),
            });
          } else if (msg.type === 'input_transcript' && msg.text) {
            setInputTranscript({
              id: `in-${Date.now()}`,
              text: msg.text,
              timestamp: Date.now(),
            });
          } else if (msg.type === 'learner_update' && msg.snapshot) {
            applyLearnerSnapshot(msg.snapshot as LearnerSnapshot);
          } else if (msg.type === 'learner_update_v2' && msg.evidence) {
            // T10/T23 — a real diagnosis + evidence record from
            // recordReasoningEvidence, distinct from the older liveObserver
            // snapshot above. Feeds the reasoning panel's live feed and
            // nudges the profile panel's mastery display.
            const evidence = msg.evidence as EvidenceResultUI;
            const diagnosis = msg.diagnosis as DiagnosisUpdateUI | undefined;
            setReasoningLog(prev => [...prev, {
              id: evidence.eventId || `diag-${Date.now()}`,
              timestamp: Date.now(),
              kind: 'diagnosis',
              diagnosis,
              evidence,
            }].slice(-40));
            if (diagnosis) {
              setLiveMastery(evidence.masteryAfter);
              setLiveMisconceptions(evidence.ledger.map(m => ({ id: m.id, text: m.text, status: m.status })));
            }
          } else if (msg.type === 'plan_update' && msg.instruction) {
            // T19/T20 — the in-session plan delta pushed after every
            // diagnosis (src/plan/delta.ts). This is guidance for the panel
            // and for a future direct-injection path (T19); it never talks
            // to the voice model directly today.
            setReasoningLog(prev => [...prev, {
              id: `plan-${Date.now()}`,
              timestamp: Date.now(),
              kind: 'plan_update',
              planUpdate: {
                instruction: String(msg.instruction),
                nextRepresentation: msg.nextRepresentation,
                outcome: msg.outcome,
                moveUsed: msg.moveUsed,
              } as PlanUpdateUI,
            }].slice(-40));
          } else if (msg.type === 'session_ready') {
            setConnectionStatus('connected');
            setLearnerSnap(null); setLiveMastery(0); setLiveMisconceptions([]); setLiveAssessment(null);
            // Reset the figure to blank — the AI now controls what is revealed step by step.
            // This is the start of the concreteness-fading teaching sequence.
            setRevealed([]);
            setFocusPart(null);
            // The board picture, likewise, is built up again from its first step as the tutor speaks.
            setVisualStep(0);
            setVisual3dStep(0);
            setVisualSpotlight([]);
          } else if (msg.type === 'interrupted') {
            audioMgr.flushPlayback();
          } else if (msg.type === 'tool_call') {
            handleToolCall(msg.name, msg.args);
          } else if (msg.type === 'error') {
            console.error('[WebSocket] Server reported error:', msg);
            setConnectionStatus('error');
            if (msg.message) {
              setOutputTranscript({
                id: `err-${Date.now()}`,
                text: String(msg.message),
                timestamp: Date.now(),
              });
            }
          }
        } catch (parseErr) {
          console.error('[WebSocket] Message parsing error:', parseErr);
        }
      };

      socket.onerror = (err) => {
        console.error('[WebSocket] Socket error:', err);
        setConnectionStatus('error');
      };

      socket.onclose = () => {
        console.log('[WebSocket] Connection closed');
        setConnectionStatus('disconnected');
        setMicLevel(0);
      };
    } catch (err: any) {
      console.error('[App] Failed to start voice session:', err);
      setConnectionStatus('error');
    }
  };

  // A confusion button is the child speaking. It goes into the conversation as
  // a real turn so the tutor responds to it, and it is never framed as a failure.
  const CONFUSION_PHRASES: Record<string, string> = {
    dont_understand:    "I don't understand this bit.",
    repeat_differently: 'Can you explain that a different way?',
    too_fast:           "That's going a bit too fast for me.",
    guessed:            'I should say — I guessed that one.',
  };

  // Everything on the learner panel comes from here once a session is running.
  const applyLearnerSnapshot = useCallback((snap: LearnerSnapshot) => {
    setLearnerSnap(snap);
    setLiveMastery(snap.understanding);
    setLiveMisconceptions(snap.misconceptions.map(m => ({ id: m.id, text: m.text, status: m.status })));
    setLiveAssessment(prev => ({
      ...(prev || { classification: 'observed', understandingDepth: snap.level, confidence: 'medium' as const }),
      understandingDepth: snap.level,
      concept: snap.concept,
      probeQuestion: snap.probeQuestion || null,
      mastery: { before: prev?.mastery?.after ?? 0, after: snap.understanding, derivation: 'live observer' },
      misconceptions: snap.misconceptions,
    }));
    if (snap.evidence) {
      const open = snap.misconceptions.some(m => m.status !== 'resolved' && m.evidence && snap.evidence.includes(m.evidence.slice(0, 20)));
      const sound = ['explains', 'applies', 'transfers'].includes(snap.level);
      setStudentThinking({ method: snap.evidence, verdict: open ? 'checking' : sound ? 'sound' : 'checking' });
    }
  }, []);

  const handleConfusion = useCallback((signal: string) => {
    const phrase = CONFUSION_PHRASES[signal] || CONFUSION_PHRASES.dont_understand;
    setInputTranscript({ id: `confusion-${Date.now()}`, text: phrase, timestamp: Date.now() });
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'text', text: phrase }));
    } else {
      setOutputTranscript({
        id: `confusion-ack-${Date.now()}`,
        text: "Good — telling me that is genuinely the most useful thing you can do. Start the voice lesson and I'll take it from there, slower.",
        timestamp: Date.now(),
      });
    }
  }, []);

  // Note: figure parts are pre-shown on lesson load (full overview) and reset to []
  // on session_ready so the AI controls progressive reveal during the voice session.

  // ─── "Thinking" indicator ──────────────────────────────────────
  // Gap between the child finishing and the tutor's first word: show that the
  // tutor heard them, instead of a silent screen. Driven only by the mic level
  // and the tutor's own output level — the voice connection is not touched.
  const micRef = useRef(0);
  const tutorSpeakingRef = useRef(false);
  const tutorQuietSinceRef = useRef(0);
  useEffect(() => { micRef.current = micLevel; }, [micLevel]);
  useEffect(() => {
    tutorSpeakingRef.current = tutorState.isSpeaking;
    if (tutorState.isSpeaking) setThinking(false);
    else tutorQuietSinceRef.current = Date.now();
  }, [tutorState.isSpeaking, setThinking]);
  useEffect(() => {
    if (connectionStatus !== 'connected') { setThinking(false); return; }
    let speechMs = 0, quietMs = 0, heardChild = false;
    const iv = window.setInterval(() => {
      // While the tutor talks (and just after), the mic mostly hears the tutor.
      if (tutorSpeakingRef.current || Date.now() - tutorQuietSinceRef.current < 400) {
        speechMs = 0; quietMs = 0; heardChild = false; return;
      }
      if (micRef.current > 0.12) {
        speechMs += 100; quietMs = 0;
        if (speechMs >= 300) heardChild = true;
      } else {
        quietMs += 100;
        if (quietMs >= 300) speechMs = 0;
        if (heardChild && quietMs >= 600) { heardChild = false; setThinking(true); }
      }
    }, 100);
    return () => window.clearInterval(iv);
  }, [connectionStatus, setThinking]);

  // Send a suggested question as student voice/text prompt
  const handleAskSuggestedQuestion = (questionText: string) => {
    setInputTranscript({
      id: `ask-${Date.now()}`,
      text: questionText,
      timestamp: Date.now(),
    });

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'text', text: questionText }));
    } else {
      setOutputTranscript({
        id: `ans-${Date.now()}`,
        text: `Regarding "${questionText}": Notice how our dynamic 2D schematic, 3D spatial scene, and chalkboard lecture notes outline the underlying steps. Click "Start Voice Lesson" to discuss this with me live!`,
        timestamp: Date.now(),
      });
    }
  };

  // Handle Command / Ask from Blackboard
  const handleAskVisualOrCommand = (command: string) => {
    setInputTranscript({
      id: `cmd-${Date.now()}`,
      text: command,
      timestamp: Date.now(),
    });

    const lower = command.toLowerCase();

    // Check if user is asking for a new topic: e.g. "teach me about X" or "topic: X"
    if (lower.startsWith('teach me about ') || lower.startsWith('topic: ') || lower.startsWith('switch to ')) {
      const extractedTopic = command
        .replace(/^(teach me about|topic:|switch to)\s+/i, '')
        .trim();
      if (extractedTopic) {
        handleApplyTopicAndGrade(extractedTopic);
        return;
      }
    }

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'text', text: command }));
    } else {
      if (lower.includes('3d')) {
        setBlackboard((prev) => ({ ...prev, activeTab: '3d' }));
        setOutputTranscript({
          id: `cmd-resp-${Date.now()}`,
          text: `Switched to 3D spatial visualization! You can rotate the 3D model 360° and inspect structural coordinates.`,
          timestamp: Date.now(),
        });
      } else if (lower.includes('photo') || lower.includes('picture')) {
        handleGeneratePhoto(command);
      } else if (lower.includes('2d') || lower.includes('diagram')) {
        setBlackboard((prev) => ({ ...prev, activeTab: '2d' }));
      } else if (lower.includes('chalk') || lower.includes('note')) {
        setBlackboard((prev) => ({ ...prev, activeTab: 'chalkboard' }));
      } else if (lower.includes('quiz')) {
        setBlackboard((prev) => ({ ...prev, activeTab: 'quiz' }));
      }
    }
  };

  // ─── Screen navigation handlers ─────────────────────────────
  const handleLogin = (profile: StudentProfile) => {
    setLoggedInStudent(profile);
    setGrade(profile.grade);
    // Only new/incomplete learners see onboarding — a returning learner who
    // already finished it (learner.onboarding?.completedAt is set) goes
    // straight to subject-select.
    setScreen(profile.onboarding?.completedAt ? 'subject-select' : 'onboarding');
  };

  const handleSubjectConceptSelect = async (
    subjectId: string, subjectLabel: string,
    conceptId: string, conceptLabel: string, studentGrade: string
  ) => {
    if (!loggedInStudent) return;
    try {
      const res = await authFetch('/api/session/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: loggedInStudent.studentId,
          name: loggedInStudent.name,
          grade: studentGrade,
          subjectId,
          // Bug found 2026-09-26: this was never sent, so picking a specific
          // concept here had no effect — the server always auto-picked the
          // next unmastered concept by curriculum order instead.
          conceptId,
        }),
      });
      const json = await res.json();
      if (json.sessionId) {
        setSessionId(json.sessionId);
        setLearnerProfile(json.learner);
        setAdaptiveSession(json.session || {
          sessionId: json.sessionId,
          studentId: loggedInStudent.studentId,
          subjectId,
          currentConceptId: conceptId,
          currentStrategy: 'direct_explanation',
          sessionStarted: Date.now(), interactionCount: 0, recentAttempts: [],
        });
        setCurrentConcept(json.currentConcept || null);
        // Bug fixed 2026-09-26: this path (the normal one — picking a concept
        // on the Subjects screen) never stored the compiled plan, so the
        // Tutor's-reasoning panel was empty for every session started here;
        // only the legacy handleStartSession path set it.
        setTeachingPlan(json.plan || null);
        setReasoningLog([]);
        // Panel stays closed — user can open it via the Profile button in the top nav
      }
    } catch (err) { console.error('[Session] Failed to start:', err); }
    lessonConceptRef.current = { id: conceptId, label: conceptLabel };
    setTopic(conceptLabel);
    setGrade(studentGrade);
    setScreen('tutor');
    loadLesson(conceptLabel, studentGrade);
    setOutputTranscript({
      id: `welcome-${Date.now()}`,
      text: `Hi ${loggedInStudent?.name || 'there'}! Today we are diving into "${conceptLabel}". I have prepared this session just for you — let's go!`,
      timestamp: Date.now(),
    });
  };

  // ─── Screen rendering ─────────────────────────────────────────
  if (screen === 'login') {
    return (
      <LoginScreen
        onLogin={handleLogin}
        onParentPortal={() => setScreen('parent-portal')}
        onAdmin={() => setScreen('admin')}
      />
    );
  }

  if (screen === 'admin') {
    return <AdminLibrary onBack={() => setScreen(loggedInStudent ? 'subject-select' : 'login')} />;
  }

  if (screen === 'onboarding' && loggedInStudent) {
    return (
      <Onboarding
        student={loggedInStudent}
        onDone={() => setScreen('subject-select')}
      />
    );
  }

  if (screen === 'parent-portal') {
    return (
      <>
        <ParentPortal
          onBack={() => setScreen(loggedInStudent ? 'subject-select' : 'login')}
          initialStudentId={loggedInStudent?.studentId}
        />
      </>
    );
  }

  if (screen === 'subject-select' && loggedInStudent) {
    return (
      <>
        <SubjectSelector
          student={loggedInStudent as any}
          onSelectSubjectConcept={handleSubjectConceptSelect}
          onLogout={() => { setLoggedInStudent(null); setScreen('login'); }}
          onParentPortal={() => setScreen('parent-portal')}
        />
      </>
    );
  }

  // ─── Main tutor screen ────────────────────────────────────────
  return (
    <div
      id="app-root"
      className={`w-screen h-screen flex flex-col font-sans antialiased overflow-hidden select-none ${
        BOARD_SURFACE === 'immersive' ? 'bg-[#0C0F16] text-white' : 'bg-[#F6F7F9] text-[#161A22]'
      }`}
    >
      {/* GLOBAL TOP NAVIGATION — immersive supplies its own single bar. */}
      {BOARD_SURFACE !== 'immersive' && (
      <header
        id="top-nav-bar"
        className={`h-14 w-full px-4 flex items-center justify-between z-30 ${
          BOARD_SURFACE === 'immersive'
            ? 'bg-[#0C0F16] border-b border-white/[0.07]'
            : 'bg-[#FFFFFF] border-b border-[#E3E6EC] shadow-md'
        }`}
      >
        {/* Brand & Identity */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-emerald-500 to-amber-400 p-0.5 flex items-center justify-center shadow-md">
            <Sparkles className="w-4 h-4 text-black" />
          </div>
          <div>
            <span className="text-sm font-bold tracking-wider text-white uppercase font-mono flex items-center gap-1.5">
              <span>AI Interactive Tutor</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                ON THE FLY
              </span>
            </span>
          </div>
        </div>

        {/* Center: Dynamic Topic & Grade Selector */}
        <TopicGradeSelector
          currentTopic={topic}
          currentGrade={grade}
          onApplyTopicAndGrade={handleApplyTopicAndGrade}
          isLoading={blackboard.isLoading}
        />

        {/* Right: Student info + controls */}
        <div className="flex items-center gap-2">
          {loggedInStudent && (
            <button
              onClick={() => setScreen('subject-select')}
              className="p-1.5 rounded-lg bg-[#FFFFFF] hover:bg-[#F1F0FE] border border-[#DDE1E8] text-[#8A93A3] hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 px-2.5"
            >
              <span className="text-xs font-medium">← Subjects</span>
            </button>
          )}
          <button
            onClick={() => setProfilePanelOpen(p => !p)}
            title="Learner profile"
            className="p-1.5 rounded-lg bg-[#FFFFFF] hover:bg-[#F1F0FE] border border-[#DDE1E8] text-[#8A93A3] hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 px-2.5"
          >
            <span className="text-xs font-medium">👤 {loggedInStudent?.name || 'Profile'}</span>
          </button>
          {topic && (
            <button
              onClick={() => loadLesson(topic, grade)}
              disabled={blackboard.isLoading}
              title="Regenerate dynamic lesson"
              className="p-1.5 rounded-lg bg-[#FFFFFF] hover:bg-[#F1F0FE] border border-[#DDE1E8] text-[#8A93A3] hover:text-white transition-colors cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${blackboard.isLoading ? 'animate-spin' : ''}`} />
            </button>
          )}
        </div>
      </header>
      )}

      {/* MAIN WORKSPACE */}
      <main id="main-workspace" className="flex-1 w-full flex flex-row overflow-hidden min-h-0">
        {/* Left: Animated Vector Character Tutor — only for the non-immersive surfaces,
            since the immersive stage carries its own presenter. */}
        {BOARD_SURFACE !== 'immersive' && (
        <section
          id="animated-tutor-section"
          className="w-[30%] min-w-[280px] max-w-[380px] h-full flex flex-col min-h-0"
        >
          <AnimatedTutorCharacter
            tutorState={tutorState}
            outputTranscript={outputTranscript}
            inputTranscript={inputTranscript}
            currentTopic={topic}
            currentGrade={grade}
          />
        </section>
        )}

        {/* Right: Teaching surface */}
        <section id="dynamic-blackboard-section" className="flex-1 h-full relative min-h-0">
          {BOARD_SURFACE === 'immersive' ? (
            <ImmersiveStage
              conceptLabel={liveAssessment?.concept?.label || currentConcept?.label || topic || 'Your lesson'}
              subject={blackboard.lessonData?.subject || 'Maths'}
              grade={grade}
              figure={figure}
              revealed={revealed}
              focusPart={focusPart}
              studentThinking={studentThinking}
              assessment={liveAssessment}
              notes={boardNote}
              liveNotes={blackboard.customLiveNotes}
              masteryScore={liveMastery}
              misconceptions={liveMisconceptions}
              isLessonActive={connectionStatus === 'connected' || connectionStatus === 'reconnecting'}
              isSpeaking={tutorState.isSpeaking}
              isThinking={tutorThinking}
              learner={learnerSnap}
              mouthOpenness={tutorState.mouthOpenness}
              micLevel={micLevel}
              panelMode={panelMode}
              scene={getScene(sceneId)}
              topicDiagram={blackboard.lessonData?.diagram}
              scene3d={blackboard.lessonData?.scene3d}
              visual={blackboard.lessonData?.visual ?? null}
              visual3d={blackboard.lessonData?.visual3d ?? null}
              visualStep={visualStep}
              visual3dStep={visual3dStep}
              onVisualStepChange={setVisualStep}
              onVisual3dStepChange={setVisual3dStep}
              visualSpotlight={visualSpotlight}
              pregenPhoto={pregenPhoto}
              pregenPhotoCaption={pregenPhotoCaption}
              tutorLine={outputTranscript?.text}
              presenter={PRESENTER}
              studentName={loggedInStudent?.name}
              onChangeTopic={() => setScreen('subject-select')}
              onOpenProfile={() => setProfilePanelOpen(p => !p)}
              onPanelModeChange={setPanelMode}
              onConfusion={handleConfusion}
              onToggleLesson={toggleVoiceLesson}
            />
          ) : BOARD_SURFACE === 'canvas' ? (
            <TeachingCanvas
              topic={topic || 'Your lesson'}
              conceptLabel={liveAssessment?.concept?.label || currentConcept?.label || topic}
              figure={figure}
              revealed={revealed}
              focusPart={focusPart}
              studentThinking={studentThinking}
              assessment={liveAssessment}
              notes={boardNote}
              masteryScore={liveMastery}
              misconceptions={liveMisconceptions}
              isLessonActive={connectionStatus === 'connected'}
              onConfusion={handleConfusion}
            />
          ) : (
          <DynamicBlackboard
            blackboard={blackboard}
            onTabChange={(tab) => setBlackboard((prev) => ({ ...prev, activeTab: tab }))}
            onNodeClick={(node: ConceptNode) => {
              setBlackboard((prev) => ({
                ...prev,
                highlightedNodeId: prev.highlightedNodeId === node.id ? null : node.id,
              }));
              setOutputTranscript({
                id: `node-${Date.now()}`,
                text: `Looking at "${node.label}": ${node.details}`,
                timestamp: Date.now(),
              });
            }}
            onVariableChange={(varId, val) => {
              setBlackboard((prev) => ({
                ...prev,
                interactiveValues: {
                  ...prev.interactiveValues,
                  [varId]: val,
                },
              }));
            }}
            onQuizAnswer={(idx, reasoning) => {
              if (sessionId) {
                handleAdaptiveQuizAnswer(idx, reasoning);
              } else {
                setBlackboard((prev) => ({
                  ...prev,
                  selectedQuizOption: idx,
                  showQuizResult: true,
                }));
              }
            }}
            onAskSuggestedQuestion={handleAskSuggestedQuestion}
            onSetTopicOnTheFly={handleApplyTopicAndGrade}
            onAskVisualOrCommand={handleAskVisualOrCommand}
            onGeneratePhoto={handleGeneratePhoto}
          />
          )}
        </section>
      </main>

      {/* ADAPTIVE COMPONENTS */}
      <LearnerProfilePanel
        hideTab={BOARD_SURFACE === 'immersive'}
        learner={learnerProfile}
        session={adaptiveSession}
        currentConcept={currentConcept}
        lastAssessment={lastAssessment}
        onStartSession={handleStartSession}
        onAssessQuiz={handleAdaptiveQuizAnswer as any}
        sessionId={sessionId}
        isVisible={profilePanelOpen}
        onToggle={() => setProfilePanelOpen(p => !p)}
      />
      <TutorReasoningPanel
        plan={teachingPlan}
        log={reasoningLog}
        isVisible={reasoningPanelOpen}
        onToggle={() => setReasoningPanelOpen(p => !p)}
      />

      {/* BOTTOM CONTROL BAR — immersive stage supplies its own, so skip it there. */}
      {BOARD_SURFACE !== 'immersive' && (
      <BottomBar
        isLessonActive={connectionStatus === 'connected' || connectionStatus === 'connecting'}
        connectionStatus={connectionStatus}
        micLevel={micLevel}
        currentTopic={topic || 'Any Topic on the Fly'}
        onToggleLesson={toggleVoiceLesson}
      />
      )}
    </div>
  );
};

export default App;
